# NextEmulator — Setup Guide

## Requirements

| Tool | Minimum version |
|---|---|
| Android Studio | Hedgehog (2023.1.1) or later |
| Android NDK | r27 (API level 35 support) |
| CMake | 3.22.1 (installed via SDK Manager) |
| JDK | 17 (bundled with Android Studio) |
| Target Android | 10+ (API 29) — Vulkan 1.1 guaranteed |

---

## Quick Start

```bash
# 1. Clone / extract the project
unzip NextEmulator.zip
cd NextEmulator

# 2. Create local.properties (copy the template, fill in SDK path)
cp local.properties.template local.properties
# Edit local.properties — set sdk.dir to your Android SDK path

# 3. Open in Android Studio
# File → Open → select this directory

# 4. Sync Gradle (Android Studio will prompt automatically)
# SDK Manager → install: NDK (Side-by-side) r27, CMake 3.22.1

# 5. Connect your device (USB debugging enabled) or use AVD
# Device: arm64 physical device strongly recommended (Vulkan required)

# 6. Build & run
# Run → Run 'app'  (or Shift+F10)
```

---

## Project Structure

```
NextEmulator/
├── app/
│   ├── build.gradle.kts          ← Gradle config (API 35, NDK, Oboe)
│   ├── proguard-rules.pro        ← Release obfuscation rules
│   └── src/main/
│       ├── AndroidManifest.xml   ← Permissions, features
│       ├── cpp/                  ← Native C++20 code
│       │   ├── CMakeLists.txt    ← NDK build config (-O3, armv8.2-a)
│       │   ├── NativeEmulatorCore.cpp  ← JNI backbone + thread management
│       │   ├── dbt/              ← x86_64 → ARM64 Dynamic Binary Translation
│       │   │   ├── x86_64_decoder.{h,cpp}
│       │   │   ├── arm64_emitter.{h,cpp}
│       │   │   └── translation_cache.{h,cpp}
│       │   ├── vulkan/           ← Vulkan renderer (Mali-G57 optimised)
│       │   │   ├── VulkanRenderer.{h,cpp}
│       │   │   ├── ShaderCache.{h,cpp}
│       │   │   └── DynamicResolutionScaler.{h,cpp}
│       │   ├── audio/            ← Google Oboe zero-latency audio
│       │   │   └── OboeAudioEngine.{h,cpp}
│       │   ├── memory/           ← mmap guest VA + save states
│       │   │   ├── MemoryMapper.{h,cpp}
│       │   │   └── SaveStateManager.{h,cpp}
│       │   └── network/          ← Virtual LAN multiplayer
│       │       └── VirtualLAN.{h,cpp}
│       └── java/com/nextemulator/
│           ├── MainActivity.kt           ← Entry point, navigation
│           ├── core/
│           │   ├── EmulatorEngine.kt     ← JNI wrapper + StateFlow
│           │   ├── GameProfile.kt        ← Per-game config + repository
│           │   └── ScanCodes.kt          ← Windows scan code constants
│           ├── ui/
│           │   ├── ModernGameController.kt  ← PUBG-style HUD + gyro
│           │   ├── EmulatorScreen.kt        ← SurfaceView + overlay
│           │   ├── LibraryScreen.kt         ← Game grid + launch
│           │   ├── AddGameScreen.kt         ← File picker
│           │   ├── GameSettingsScreen.kt    ← Per-game settings
│           │   └── theme/Theme.kt           ← Dark Compose theme
│           ├── modding/
│           │   └── ModManager.kt         ← Runtime mod injection
│           └── storage/
│               └── FileSystemManager.kt  ← ISO/CHD mounting + SAF
├── CONFIG_PROFILES.md            ← Mali-G57 / Unisoc tuning reference
└── gradle/libs.versions.toml     ← Dependency version catalog
```

---

## Next Development Steps

### Phase 1 — Wire up Wine (required for .exe execution)
1. Build Wine for ARM64 from source or use the pre-built `wine-arm64` package
2. Place the Wine runtime in `app/src/main/assets/wine/`
3. In `NativeEmulatorCore.cpp → nativeInit()`, extract and configure the Wine prefix
4. Point `WineLoader` at the extracted runtime before calling `nativeStart()`

### Phase 2 — Box64 or FEX-Emu integration (DBT engine)
The `dbt/` module contains a structural x86_64 decoder skeleton.
For production-grade translation, integrate one of:
- **Box64** — lighter, optimised for ARM64 mobile, good single-threaded perf
- **FEX-Emu** — more complete, JIT recompiler, better multi-thread scaling

Clone the chosen project and add it as a CMake `add_subdirectory()` dependency.
Replace the stub `X86_64Decoder::fetch_next_block()` with calls into the engine's
fetch/translate API.

### Phase 3 — DXVK build
DXVK must be cross-compiled from x86_64 Windows DLLs to be loaded by Wine.
Use the DXVK project's `package-release.sh` script with a MinGW cross-compiler
targeting `x86_64-w64-mingw32`.

### Phase 4 — Shader cache integration
Pre-compiled SPIR-V blobs for common D3D9/D3D11 shaders should be bundled in
`app/src/main/assets/shaders/` and extracted to `cacheDir` on first launch.
`ShaderCache` is already wired to load from `cacheDir`.

---

## Tuning for Unisoc UMS9230H

See `CONFIG_PROFILES.md` for the complete table of:
- Vulkan pipeline settings (AFBC, tile rendering, present mode)
- DXVK environment variables
- Thread affinity map (A75 big cores → DBT, A55 little cores → render/IO/audio)
- Dynamic resolution scaling thresholds (fps target, temperature cap)
- Memory budget breakdown (target RSS < 700 MB)
