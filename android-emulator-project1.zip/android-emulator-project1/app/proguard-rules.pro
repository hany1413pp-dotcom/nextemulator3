# NextEmulator ProGuard rules

# Keep JNI classes (called from native code)
-keep class com.nextemulator.core.EmulatorEngine {
    public void onFpsUpdate(float);
    public void onThermalWarning();
}

# Kotlin coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}

# Kotlinx serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class com.nextemulator.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Oboe native library
-keep class com.google.oboe.** { *; }

# Coil
-dontwarn okhttp3.**
-dontwarn okio.**

# Keep native methods
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}
