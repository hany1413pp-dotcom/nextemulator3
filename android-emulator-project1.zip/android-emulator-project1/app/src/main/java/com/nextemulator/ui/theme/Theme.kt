package com.nextemulator.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary         = Color(0xFF3A86FF),
    onPrimary       = Color.White,
    secondary       = Color(0xFF7B61FF),
    onSecondary     = Color.White,
    tertiary        = Color(0xFFFF6B35),
    background      = Color(0xFF0A0A1A),
    surface         = Color(0xFF13132A),
    onBackground    = Color.White,
    onSurface       = Color.White,
    error           = Color(0xFFF44336),
    onError         = Color.White
)

@Composable
fun NextEmulatorTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography  = androidx.compose.material3.Typography(),
        content     = content
    )
}
