package com.nextemulator.core

import android.content.Context
import android.util.Log
import android.view.Surface
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * EmulatorEngine — Kotlin wrapper over the native JNI core.
 *
 * Owns the lifecycle of the native emulator: init → start → pause/resume → stop → destroy.
 * Exposes observable state (FPS, thermal warnings) via Kotlin StateFlow.
 */
class EmulatorEngine(private val context: Context) {

    companion object {
        private const val TAG = "EmulatorEngine"

        init {
            System.loadLibrary("nextemulator")
        }
    }

    // ── Observable state ──────────────────────────────────────────────────────
    private val _fps = MutableStateFlow(0f)
    val fps: StateFlow<Float> = _fps.asStateFlow()

    private val _thermalWarning = MutableStateFlow(false)
    val thermalWarning: StateFlow<Boolean> = _thermalWarning.asStateFlow()

    private val _state = MutableStateFlow(EngineState.IDLE)
    val state: StateFlow<EngineState> = _state.asStateFlow()

    enum class EngineState { IDLE, INITIALISED, RUNNING, PAUSED, STOPPED, ERROR }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    fun init(): Boolean {
        val cacheDir  = context.cacheDir.absolutePath
        val prefixDir = context.filesDir.absolutePath + "/wineprefix"
        val result    = nativeInit(cacheDir, prefixDir)
        if (result == 0) {
            _state.value = EngineState.INITIALISED
            Log.i(TAG, "Engine initialised")
        } else {
            _state.value = EngineState.ERROR
            Log.e(TAG, "nativeInit failed: $result")
        }
        return result == 0
    }

    fun onSurfaceCreated(surface: Surface) {
        nativeSurfaceCreated(surface)
    }

    fun onSurfaceDestroyed() {
        nativeSurfaceDestroyed()
    }

    fun start(execPath: String): Boolean {
        if (_state.value !in listOf(EngineState.INITIALISED, EngineState.STOPPED)) {
            Log.w(TAG, "Cannot start from state ${_state.value}")
            return false
        }
        val result = nativeStart(execPath)
        return if (result == 0) {
            _state.value = EngineState.RUNNING
            Log.i(TAG, "Emulator started: $execPath")
            true
        } else {
            _state.value = EngineState.ERROR
            Log.e(TAG, "nativeStart failed: $result for $execPath")
            false
        }
    }

    fun pause() {
        nativePause(true)
        _state.value = EngineState.PAUSED
    }

    fun resume() {
        nativePause(false)
        _state.value = EngineState.RUNNING
    }

    fun stop() {
        nativeStop()
        _state.value = EngineState.STOPPED
    }

    fun destroy() {
        nativeDestroy()
        _state.value = EngineState.IDLE
    }

    // ── Input ─────────────────────────────────────────────────────────────────
    fun sendKey(scanCode: Int, pressed: Boolean)    = nativeSendKeyEvent(scanCode, pressed)
    fun sendMouseDelta(dx: Float, dy: Float)         = nativeSendMouseDelta(dx, dy)
    fun sendAxis(axis: Int, value: Float)            = nativeSendAxisEvent(axis, value)

    // ── Save states ───────────────────────────────────────────────────────────
    suspend fun saveState(slot: Int): Boolean = kotlinx.coroutines.withContext(Dispatchers.IO) {
        nativeSaveState(slot)
    }

    suspend fun loadState(slot: Int): Boolean = kotlinx.coroutines.withContext(Dispatchers.IO) {
        nativeLoadState(slot)
    }

    // ── JNI callbacks (called from native thread) ─────────────────────────────
    @Suppress("unused") // called from C++
    fun onFpsUpdate(fps: Float) {
        _fps.value = fps
    }

    @Suppress("unused") // called from C++
    fun onThermalWarning() {
        scope.launch { _thermalWarning.value = true }
        Log.w(TAG, "Thermal warning received from native core")
    }

    // ── JNI declarations ─────────────────────────────────────────────────────
    private external fun nativeInit(cacheDir: String, prefixDir: String): Int
    private external fun nativeSurfaceCreated(surface: Surface)
    private external fun nativeSurfaceDestroyed()
    private external fun nativeStart(execPath: String): Int
    private external fun nativeStop()
    private external fun nativePause(paused: Boolean)
    private external fun nativeSendKeyEvent(scanCode: Int, pressed: Boolean)
    private external fun nativeSendMouseDelta(dx: Float, dy: Float)
    private external fun nativeSendAxisEvent(axis: Int, value: Float)
    private external fun nativeSaveState(slot: Int): Boolean
    private external fun nativeLoadState(slot: Int): Boolean
    private external fun nativeDestroy()
}
