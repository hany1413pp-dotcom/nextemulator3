package com.nextemulator.ui

import android.content.Context
import android.hardware.SensorManager
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.nextemulator.core.EmulatorEngine
import com.nextemulator.core.GameProfile

/**
 * EmulatorScreen — the full-screen emulation surface with the HUD overlay.
 *
 * Hosts a SurfaceView (which Vulkan renders into) and composites the
 * ModernGameController overlay on top via a Box layout.
 */
@Composable
fun EmulatorScreen(
    engine:      EmulatorEngine,
    profile:     GameProfile,
    modifier:    Modifier = Modifier
) {
    val context       = LocalContext.current
    val sensorManager = remember {
        context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    }

    LaunchedEffect(profile) {
        engine.init()
    }

    Box(modifier = modifier.fillMaxSize()) {

        // ── Native Vulkan surface ─────────────────────────────────────────────
        AndroidView(
            factory = { ctx ->
                SurfaceView(ctx).apply {
                    holder.addCallback(object : SurfaceHolder.Callback {
                        override fun surfaceCreated(holder: SurfaceHolder) {
                            engine.onSurfaceCreated(holder.surface)
                            engine.start(profile.execPath)
                        }
                        override fun surfaceDestroyed(holder: SurfaceHolder) {
                            engine.onSurfaceDestroyed()
                        }
                        override fun surfaceChanged(holder: SurfaceHolder,
                                                    format: Int, w: Int, h: Int) {}
                    })
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // ── On-screen controller overlay ──────────────────────────────────────
        ModernGameController(
            engine        = engine,
            sensorManager = sensorManager,
            modifier      = Modifier.fillMaxSize()
        )
    }

    DisposableEffect(Unit) {
        onDispose {
            engine.stop()
            engine.destroy()
        }
    }
}
