package com.nextemulator.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nextemulator.core.GameProfile

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameSettingsScreen(
    profile: GameProfile,
    onSave:  (GameProfile) -> Unit,
    onBack:  () -> Unit
) {
    var targetFps       by remember { mutableStateOf(profile.targetFps.toFloat()) }
    var resScale        by remember { mutableFloatStateOf(profile.resolutionScale) }
    var dxvkEnabled     by remember { mutableStateOf(profile.dxvkEnabled) }
    var esyncEnabled    by remember { mutableStateOf(profile.esyncEnabled) }
    var fsyncEnabled    by remember { mutableStateOf(profile.fsyncEnabled) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(profile.name, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Performance Settings", color = Color.White.copy(alpha = 0.5f),
                             fontSize = 12.sp)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0A0A1A)),
                actions = {
                    TextButton(onClick = {
                        onSave(profile.copy(
                            targetFps       = targetFps.toInt(),
                            resolutionScale = resScale,
                            dxvkEnabled     = dxvkEnabled,
                            esyncEnabled    = esyncEnabled,
                            fsyncEnabled    = fsyncEnabled
                        ))
                    }) {
                        Text("Save", color = Color(0xFF3A86FF))
                    }
                }
            )
        },
        containerColor = Color(0xFF0A0A1A)
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // ── Target FPS ────────────────────────────────────────────────────
            SettingsSection(title = "Frame Rate") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Target: ${targetFps.toInt()} FPS",
                         color = Color.White, modifier = Modifier.weight(1f))
                }
                Slider(
                    value         = targetFps,
                    onValueChange = { targetFps = it },
                    valueRange    = 20f..120f,
                    steps         = 5,
                    colors        = SliderDefaults.colors(thumbColor = Color(0xFF3A86FF))
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(30, 60, 90, 120).forEach { fps ->
                        FilterChip(
                            selected = targetFps.toInt() == fps,
                            onClick  = { targetFps = fps.toFloat() },
                            label    = { Text("${fps}fps") },
                            colors   = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF3A86FF),
                                selectedLabelColor     = Color.White
                            )
                        )
                    }
                }
            }

            // ── Resolution Scale ──────────────────────────────────────────────
            SettingsSection(title = "Resolution Scale") {
                Text("${(resScale * 100).toInt()}% — Dynamic resolution scaling",
                     color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
                Slider(
                    value         = resScale,
                    onValueChange = { resScale = it },
                    valueRange    = 0.5f..1.0f,
                    colors        = SliderDefaults.colors(thumbColor = Color(0xFF7B61FF))
                )
            }

            // ── Graphics toggles ──────────────────────────────────────────────
            SettingsSection(title = "Graphics (Vulkan)") {
                SettingsToggle("DXVK / D3D-to-Vulkan translation", dxvkEnabled) { dxvkEnabled = it }
                SettingsToggle("Asynchronous shader compile (reduces stutter)", esyncEnabled) { esyncEnabled = it }
                SettingsToggle("FSync (reduces CPU overhead, kernel req.)", fsyncEnabled) { fsyncEnabled = it }
            }

            // ── Info ──────────────────────────────────────────────────────────
            SettingsSection(title = "GPU Profile") {
                Text(
                    "Auto-detected: Mali-G57 / Vulkan 1.1\n" +
                    "AFBC tiled rendering enabled\n" +
                    "Shader cache: ${profile.id}_shaders/",
                    color    = Color.White.copy(alpha = 0.55f),
                    fontSize = 12.sp,
                    lineHeight = 20.sp
                )
            }
        }
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, color = Color(0xFF3A86FF), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        HorizontalDivider(color = Color(0xFF3A86FF).copy(alpha = 0.3f), thickness = 0.5.dp)
        content()
    }
}

@Composable
private fun SettingsToggle(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White.copy(alpha = 0.85f),
             fontSize = 13.sp, modifier = Modifier.weight(1f))
        Switch(
            checked         = checked,
            onCheckedChange = onChecked,
            colors          = SwitchDefaults.colors(checkedThumbColor = Color(0xFF3A86FF))
        )
    }
}
