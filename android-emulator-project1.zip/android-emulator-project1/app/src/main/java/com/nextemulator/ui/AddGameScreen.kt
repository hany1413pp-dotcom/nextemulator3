package com.nextemulator.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nextemulator.storage.FileSystemManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddGameScreen(
    onAdd:  (String) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var selectedPath by remember { mutableStateOf("") }
    var scanning by remember { mutableStateOf(false) }
    var scannedFiles by remember { mutableStateOf<List<FileSystemManager.GameFile>>(emptyList()) }

    val filePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { selectedPath = it.toString() }
    }

    val dirPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        uri?.let { treeUri ->
            scanning = true
            // Scan in background
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Add Game", color = Color.White, fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0A0A1A))
            )
        },
        containerColor = Color(0xFF0A0A1A)
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            Text(
                "Select a game executable or disc image",
                color    = Color.White.copy(alpha = 0.7f),
                fontSize = 14.sp
            )

            // Pick single file
            OutlinedCard(
                onClick = {
                    filePicker.launch(arrayOf(
                        "application/octet-stream",
                        "application/x-executable",
                        "*/*"
                    ))
                },
                modifier = Modifier.fillMaxWidth(),
                colors   = CardDefaults.outlinedCardColors(
                    containerColor = Color(0xFF13132A)
                ),
                border   = androidx.compose.foundation.BorderStroke(
                    1.dp, Color(0xFF3A86FF).copy(alpha = 0.5f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(Icons.Default.InsertDriveFile, null, tint = Color(0xFF3A86FF))
                    Column {
                        Text("Browse file", color = Color.White, fontWeight = FontWeight.Medium)
                        Text(".exe  .msi  .elf  .iso  .chd  .bin",
                             color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
                    }
                }
            }

            // Scan directory
            OutlinedCard(
                onClick = { dirPicker.launch(null) },
                modifier = Modifier.fillMaxWidth(),
                colors   = CardDefaults.outlinedCardColors(containerColor = Color(0xFF13132A)),
                border   = androidx.compose.foundation.BorderStroke(
                    1.dp, Color(0xFF7B61FF).copy(alpha = 0.5f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(Icons.Default.FolderOpen, null, tint = Color(0xFF7B61FF))
                    Column {
                        Text("Scan directory", color = Color.White, fontWeight = FontWeight.Medium)
                        Text("Auto-detect all games in a folder",
                             color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
                    }
                }
            }

            // Selected file indicator
            if (selectedPath.isNotEmpty()) {
                HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF1A2A1A)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF4CAF50))
                        Text(
                            selectedPath.substringAfterLast('/'),
                            color    = Color.White.copy(alpha = 0.9f),
                            fontSize = 13.sp,
                            maxLines = 2
                        )
                    }
                }

                Spacer(Modifier.weight(1f))

                Button(
                    onClick  = { onAdd(selectedPath) },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape    = RoundedCornerShape(12.dp),
                    colors   = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A86FF))
                ) {
                    Icon(Icons.Default.PlayArrow, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Add to Library", fontSize = 16.sp)
                }
            }
        }
    }
}
