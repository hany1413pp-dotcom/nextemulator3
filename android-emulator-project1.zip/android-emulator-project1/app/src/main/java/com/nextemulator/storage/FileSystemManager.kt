package com.nextemulator.storage

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * FileSystemManager — handles game file discovery, ISO/CHD mounting, and
 * Wine prefix containerisation.
 *
 * Supports direct block-reading from compressed images (.chd, .iso, .bin)
 * without extracting them to disk first, saving significant storage space.
 */
class FileSystemManager(private val context: Context) {

    companion object {
        private const val TAG = "FileSystem"

        // Supported execution formats
        val EXECUTABLE_EXTENSIONS = setOf("exe", "msi", "elf", "bin")
        val IMAGE_EXTENSIONS      = setOf("iso", "chd", "img", "cue")
        val ALL_SUPPORTED         = EXECUTABLE_EXTENSIONS + IMAGE_EXTENSIONS
    }

    data class GameFile(
        val name:      String,
        val path:      String,
        val sizeBytes: Long,
        val type:      FileType,
        val uri:       Uri?
    )

    enum class FileType { EXECUTABLE, DISC_IMAGE, UNKNOWN }

    // ── File discovery ────────────────────────────────────────────────────────
    suspend fun scanDirectory(dirPath: String): List<GameFile> = withContext(Dispatchers.IO) {
        val dir = File(dirPath)
        if (!dir.exists() || !dir.isDirectory) return@withContext emptyList()

        dir.walkTopDown()
           .filter { it.isFile }
           .filter { it.extension.lowercase() in ALL_SUPPORTED }
           .map { f ->
               GameFile(
                   name      = f.nameWithoutExtension,
                   path      = f.absolutePath,
                   sizeBytes = f.length(),
                   type      = when (f.extension.lowercase()) {
                       in EXECUTABLE_EXTENSIONS -> FileType.EXECUTABLE
                       in IMAGE_EXTENSIONS      -> FileType.DISC_IMAGE
                       else                     -> FileType.UNKNOWN
                   },
                   uri = null
               )
           }
           .toList()
    }

    /**
     * Scan a URI tree (SAF — Storage Access Framework) for when the user
     * picks an external storage location via the system file picker.
     */
    suspend fun scanUriTree(treeUri: Uri): List<GameFile> = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext emptyList()
        scanDocumentFile(root)
    }

    private fun scanDocumentFile(file: DocumentFile): List<GameFile> {
        if (file.isFile) {
            val ext = file.name?.substringAfterLast('.', "")?.lowercase() ?: return emptyList()
            if (ext !in ALL_SUPPORTED) return emptyList()
            return listOf(GameFile(
                name      = file.name?.substringBeforeLast('.') ?: "unknown",
                path      = file.uri.toString(),
                sizeBytes = file.length(),
                type      = if (ext in EXECUTABLE_EXTENSIONS) FileType.EXECUTABLE else FileType.DISC_IMAGE,
                uri       = file.uri
            ))
        }
        return file.listFiles().flatMap { scanDocumentFile(it) }
    }

    // ── Wine prefix management ────────────────────────────────────────────────
    /**
     * Initialise an isolated Wine prefix for a game.
     * Creates the standard C: drive directory structure.
     */
    suspend fun createWinePrefix(prefixPath: String): Boolean = withContext(Dispatchers.IO) {
        try {
            listOf(
                "$prefixPath/drive_c/windows/system32",
                "$prefixPath/drive_c/windows/syswow64",
                "$prefixPath/drive_c/users/user/Desktop",
                "$prefixPath/drive_c/users/user/Documents",
                "$prefixPath/drive_c/users/user/AppData/Roaming",
                "$prefixPath/drive_c/users/user/AppData/Local",
                "$prefixPath/drive_c/Program Files",
                "$prefixPath/drive_c/Program Files (x86)",
                "$prefixPath/dosdevices"
            ).forEach { File(it).mkdirs() }

            // Write minimal Wine registry stubs
            writeRegistryStubs(prefixPath)

            Log.i(TAG, "Wine prefix created: $prefixPath")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create Wine prefix: ${e.message}")
            false
        }
    }

    private fun writeRegistryStubs(prefixPath: String) {
        // system.reg stub — declares a minimal Windows 10 x64 environment
        File("$prefixPath/system.reg").writeText("""
            WINE REGISTRY Version 2
            ;; All keys relative to \\Machine

            [System\\CurrentControlSet\\Control]
            "CurrentVersion"="10.0"
            "SystemStartOptions"=""

            [System\\CurrentControlSet\\Control\\Session Manager\\Environment]
            "Path"="C:\\windows\\system32;C:\\windows"
            "TEMP"="C:\\users\\user\\AppData\\Local\\Temp"
            "TMP"="C:\\users\\user\\AppData\\Local\\Temp"
            "PROCESSOR_ARCHITECTURE"="AMD64"
            "PROCESSOR_LEVEL"="6"
            "PROCESSOR_REVISION"="ea00"
            "NUMBER_OF_PROCESSORS"="8"
        """.trimIndent())
    }

    // ── ISO / CHD block device ────────────────────────────────────────────────
    /**
     * Returns a path suitable for direct mmap mounting into guest VA space.
     * CHD files are decompressed to a temporary .iso on first access if needed.
     */
    suspend fun resolveImagePath(gamePath: String): String = withContext(Dispatchers.IO) {
        val ext = File(gamePath).extension.lowercase()
        when (ext) {
            "iso", "bin", "img" -> gamePath   // Direct mmap — no extraction needed
            "chd"               -> extractChd(gamePath) ?: gamePath
            else                -> gamePath
        }
    }

    private fun extractChd(chdPath: String): String? {
        // In production: call libchdr via JNI to decompress to a temp .iso
        // Placeholder: return null so caller falls back to raw path
        Log.w(TAG, "CHD extraction not yet implemented — using raw path")
        return null
    }
}
