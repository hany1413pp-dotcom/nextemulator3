package com.nextemulator

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.nextemulator.core.EmulatorEngine
import com.nextemulator.core.GameProfile
import com.nextemulator.core.GameProfileRepository
import com.nextemulator.ui.*
import com.nextemulator.ui.theme.NextEmulatorTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Keep screen on during emulation
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Full immersive mode (no status/nav bars during gameplay)
        window.setDecorFitsSystemWindows(false)

        setContent {
            NextEmulatorTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color    = Color(0xFF0A0A1A)
                ) {
                    NextEmulatorApp()
                }
            }
        }
    }
}

@Composable
fun NextEmulatorApp() {
    val navController  = rememberNavController()
    val context        = androidx.compose.ui.platform.LocalContext.current
    val repo           = remember { GameProfileRepository(context) }
    val scope          = rememberCoroutineScope()

    var profiles by remember { mutableStateOf<List<GameProfile>>(emptyList()) }
    var engine   by remember { mutableStateOf<EmulatorEngine?>(null) }

    LaunchedEffect(Unit) {
        profiles = repo.loadAll()
    }

    NavHost(navController = navController, startDestination = "library") {

        // ── Library ───────────────────────────────────────────────────────────
        composable("library") {
            LibraryScreen(
                profiles   = profiles,
                onLaunch   = { profile ->
                    engine = EmulatorEngine(context)
                    navController.navigate("emulator/${profile.id}")
                },
                onSettings = { profile ->
                    navController.navigate("settings/${profile.id}")
                },
                onAdd      = { navController.navigate("add_game") }
            )
        }

        // ── Emulator screen ───────────────────────────────────────────────────
        composable(
            "emulator/{profileId}",
            arguments = listOf(navArgument("profileId") { type = NavType.StringType })
        ) { backStack ->
            val profileId = backStack.arguments?.getString("profileId") ?: return@composable
            val profile   = profiles.find { it.id == profileId } ?: return@composable
            val eng       = engine ?: return@composable

            EmulatorScreen(
                engine   = eng,
                profile  = profile,
                modifier = Modifier.fillMaxSize()
            )
        }

        // ── Add game ──────────────────────────────────────────────────────────
        composable("add_game") {
            AddGameScreen(
                onAdd = { path ->
                    val profile = repo.autoDetectSettings(path)
                    scope.launch {
                        repo.save(profile)
                        profiles = repo.loadAll()
                    }
                    navController.popBackStack()
                },
                onBack = { navController.popBackStack() }
            )
        }

        // ── Settings ──────────────────────────────────────────────────────────
        composable(
            "settings/{profileId}",
            arguments = listOf(navArgument("profileId") { type = NavType.StringType })
        ) { backStack ->
            val profileId = backStack.arguments?.getString("profileId") ?: return@composable
            val profile   = profiles.find { it.id == profileId } ?: return@composable
            GameSettingsScreen(
                profile = profile,
                onSave  = { updated ->
                    scope.launch {
                        repo.save(updated)
                        profiles = repo.loadAll()
                    }
                    navController.popBackStack()
                },
                onBack  = { navController.popBackStack() }
            )
        }
    }
}
