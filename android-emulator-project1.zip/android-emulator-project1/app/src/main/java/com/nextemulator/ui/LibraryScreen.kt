package com.nextemulator.ui

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.nextemulator.core.GameProfile

/**
 * LibraryScreen — the main game library grid view.
 * Shows installed game profiles with cover art, last played time,
 * and quick-launch / settings actions.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    profiles:   List<GameProfile>,
    onLaunch:   (GameProfile) -> Unit,
    onSettings: (GameProfile) -> Unit,
    onAdd:      () -> Unit,
    modifier:   Modifier = Modifier
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("NextEmulator", fontWeight = FontWeight.Bold,
                         color = Color.White)
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0A0A1A)
                ),
                actions = {
                    IconButton(onClick = onAdd) {
                        Icon(Icons.Default.Add, "Add game", tint = Color(0xFF3A86FF))
                    }
                }
            )
        },
        containerColor = Color(0xFF0A0A1A),
        modifier        = modifier
    ) { padding ->

        if (profiles.isEmpty()) {
            EmptyLibrary(onAdd = onAdd, modifier = Modifier.fillMaxSize().padding(padding))
        } else {
            LazyVerticalGrid(
                columns             = GridCells.Adaptive(minSize = 160.dp),
                contentPadding      = PaddingValues(12.dp) + padding,
                verticalArrangement   = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier            = Modifier.fillMaxSize()
            ) {
                items(profiles) { profile ->
                    GameCard(
                        profile   = profile,
                        onLaunch  = { onLaunch(profile) },
                        onSettings= { onSettings(profile) }
                    )
                }
            }
        }
    }
}

@Composable
private fun GameCard(
    profile:    GameProfile,
    onLaunch:   () -> Unit,
    onSettings: () -> Unit,
    modifier:   Modifier = Modifier
) {
    var menuOpen by remember { mutableStateOf(false) }

    Card(
        shape   = RoundedCornerShape(12.dp),
        colors  = CardDefaults.cardColors(containerColor = Color(0xFF13132A)),
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(0.72f)
            .clickable { onLaunch() }
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Cover art
            if (profile.coverArtPath.isNotEmpty()) {
                AsyncImage(
                    model             = profile.coverArtPath,
                    contentDescription= profile.name,
                    contentScale      = ContentScale.Crop,
                    modifier          = Modifier.fillMaxSize()
                )
            } else {
                // Placeholder gradient cover
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF1A1A4E), Color(0xFF0D0D2B))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.SportsEsports, null,
                         tint = Color(0xFF3A86FF).copy(alpha = 0.4f),
                         modifier = Modifier.size(48.dp))
                }
            }

            // Bottom gradient + title
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                        )
                    )
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Column {
                    Text(
                        text     = profile.name,
                        color    = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text     = "${profile.targetFps} FPS target",
                        color    = Color.White.copy(alpha = 0.6f),
                        fontSize = 10.sp
                    )
                }
            }

            // Settings kebab menu
            Box(modifier = Modifier.align(Alignment.TopEnd).padding(4.dp)) {
                IconButton(
                    onClick  = { menuOpen = true },
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(Icons.Default.MoreVert, null,
                         tint = Color.White.copy(alpha = 0.8f))
                }
                DropdownMenu(
                    expanded        = menuOpen,
                    onDismissRequest= { menuOpen = false },
                    containerColor  = Color(0xFF1E1E3F)
                ) {
                    DropdownMenuItem(
                        text    = { Text("Settings", color = Color.White) },
                        onClick = { menuOpen = false; onSettings() },
                        leadingIcon = { Icon(Icons.Default.Settings, null, tint = Color.White) }
                    )
                    DropdownMenuItem(
                        text    = { Text("Launch", color = Color.White) },
                        onClick = { menuOpen = false; onLaunch() },
                        leadingIcon = { Icon(Icons.Default.PlayArrow, null, tint = Color(0xFF4CAF50)) }
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyLibrary(onAdd: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier              = modifier,
        verticalArrangement   = Arrangement.Center,
        horizontalAlignment   = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.VideogameAsset, null,
             tint = Color(0xFF3A86FF).copy(alpha = 0.5f),
             modifier = Modifier.size(80.dp))
        Spacer(Modifier.height(16.dp))
        Text("No games yet", color = Color.White.copy(alpha = 0.7f),
             fontSize = 20.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(8.dp))
        Text("Add your first game to get started",
             color = Color.White.copy(alpha = 0.4f), fontSize = 14.sp)
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = onAdd,
            colors  = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A86FF))
        ) {
            Icon(Icons.Default.Add, null)
            Spacer(Modifier.width(8.dp))
            Text("Add Game")
        }
    }
}
