package com.nextemulator.ui

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nextemulator.core.EmulatorEngine
import com.nextemulator.core.ScanCodes
import kotlin.math.*

// ── Controller Configuration ──────────────────────────────────────────────────
data class ControllerConfig(
    val leftStickAlpha:    Float = 0.7f,
    val rightStickAlpha:   Float = 0.7f,
    val buttonAlpha:       Float = 0.75f,
    val stickDeadZone:     Float = 0.12f,   // 12% dead zone
    val gyroSensitivity:   Float = 3.0f,    // mouse delta multiplier
    val gyroEnabled:       Boolean = false,
    val leftStickPos:      Offset = Offset(140f, -180f),  // offset from bottom-left
    val rightStickPos:     Offset = Offset(-140f, -180f), // offset from bottom-right
)

// ── Analog Joystick State ─────────────────────────────────────────────────────
data class StickState(
    val rawOffset: Offset = Offset.Zero,
    val normalised: Offset = Offset.Zero,  // [-1,1] x [-1,1]
    val magnitude: Float = 0f
)

// ── Action Button definition ──────────────────────────────────────────────────
data class ActionButton(
    val label: String,
    val scanCode: Int,
    val color: Color,
    val sizeDp: Float = 48f,
    var positionOffset: Offset = Offset.Zero
)

// ════════════════════════════════════════════════════════════════════════════
//  ModernGameController — full PUBG/Max Payne style on-screen HUD
// ════════════════════════════════════════════════════════════════════════════
@Composable
fun ModernGameController(
    engine: EmulatorEngine,
    config: ControllerConfig = ControllerConfig(),
    sensorManager: SensorManager? = null,
    onConfigChange: ((ControllerConfig) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current

    // ── Left analog stick state ───────────────────────────────────────────────
    var leftStick by remember { mutableStateOf(StickState()) }
    // ── Right analog stick state (look/aim) ───────────────────────────────────
    var rightStick by remember { mutableStateOf(StickState()) }

    // ── Gyroscope integration ─────────────────────────────────────────────────
    var gyroActive by remember { mutableStateOf(config.gyroEnabled) }

    if (gyroActive && sensorManager != null) {
        DisposableEffect(sensorManager) {
            val listener = object : SensorEventListener {
                override fun onSensorChanged(event: SensorEvent) {
                    if (event.sensor.type == Sensor.TYPE_GYROSCOPE) {
                        val dx = event.values[1] * config.gyroSensitivity * 10f
                        val dy = event.values[0] * config.gyroSensitivity * 10f
                        engine.sendMouseDelta(dx, -dy)
                    }
                }
                override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
            }
            val gyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
            sensorManager.registerListener(listener, gyro, SensorManager.SENSOR_DELAY_GAME)
            onDispose { sensorManager.unregisterListener(listener) }
        }
    }

    Box(modifier = modifier.fillMaxSize()) {

        // ── Left stick (movement) — bottom-left corner ────────────────────────
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 24.dp, bottom = 80.dp)
        ) {
            AnalogStick(
                state   = leftStick,
                alpha   = config.leftStickAlpha,
                sizeDp  = 120.dp,
                onMove  = { state ->
                    leftStick = state
                    val dx = state.normalised.x
                    val dy = state.normalised.y
                    // Map stick axes to XInput left stick (axes 0/1)
                    engine.sendAxis(0, dx)
                    engine.sendAxis(1, dy)
                    // Also synthesise WASD for keyboard-driven games
                    engine.sendKey(ScanCodes.KEY_W, dy < -config.stickDeadZone)
                    engine.sendKey(ScanCodes.KEY_S, dy >  config.stickDeadZone)
                    engine.sendKey(ScanCodes.KEY_A, dx < -config.stickDeadZone)
                    engine.sendKey(ScanCodes.KEY_D, dx >  config.stickDeadZone)
                },
                onRelease = {
                    leftStick = StickState()
                    engine.sendAxis(0, 0f); engine.sendAxis(1, 0f)
                    engine.sendKey(ScanCodes.KEY_W, false)
                    engine.sendKey(ScanCodes.KEY_S, false)
                    engine.sendKey(ScanCodes.KEY_A, false)
                    engine.sendKey(ScanCodes.KEY_D, false)
                }
            )
        }

        // ── Right stick (look/aim) — bottom-right corner ──────────────────────
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 140.dp, bottom = 80.dp)
        ) {
            AnalogStick(
                state   = rightStick,
                alpha   = config.rightStickAlpha,
                sizeDp  = 110.dp,
                color   = Color(0xFF3A86FF),
                onMove  = { state ->
                    rightStick = state
                    // Map to virtual mouse movement for FPS aiming
                    val mx = state.normalised.x * 8f
                    val my = state.normalised.y * 8f
                    engine.sendMouseDelta(mx, my)
                    // Also map to XInput right stick (axes 2/3)
                    engine.sendAxis(2, state.normalised.x)
                    engine.sendAxis(3, state.normalised.y)
                },
                onRelease = {
                    rightStick = StickState()
                    engine.sendAxis(2, 0f); engine.sendAxis(3, 0f)
                }
            )
        }

        // ── ABXY face buttons — bottom-right ──────────────────────────────────
        FaceButtons(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 20.dp, bottom = 70.dp),
            engine  = engine,
            haptic  = haptic,
            alpha   = config.buttonAlpha
        )

        // ── Shoulder / trigger buttons — top row ──────────────────────────────
        ShoulderButtons(
            modifier = Modifier
                .align(Alignment.TopStart)
                .fillMaxWidth()
                .padding(top = 8.dp, start = 8.dp, end = 8.dp),
            engine = engine,
            haptic = haptic,
            alpha  = config.buttonAlpha
        )

        // ── D-Pad ─────────────────────────────────────────────────────────────
        DPad(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 20.dp, bottom = 200.dp),
            engine = engine,
            haptic = haptic,
            alpha  = config.buttonAlpha
        )

        // ── HUD overlays: FPS counter, gyro toggle, save state ────────────────
        HudOverlay(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 12.dp, end = 12.dp),
            engine       = engine,
            gyroActive   = gyroActive,
            onGyroToggle = { gyroActive = !gyroActive }
        )
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  AnalogStick — PUBG/Max Payne style floating dynamic joystick
// ════════════════════════════════════════════════════════════════════════════
@Composable
fun AnalogStick(
    state:     StickState,
    alpha:     Float,
    sizeDp:    Dp,
    color:     Color = Color(0xFFFF6B35),
    onMove:    (StickState) -> Unit,
    onRelease: () -> Unit,
    modifier:  Modifier = Modifier
) {
    val maxRadius = with(androidx.compose.ui.platform.LocalDensity.current) {
        (sizeDp / 2).toPx()
    }

    // Smooth thumb position animation
    val thumbX by animateFloatAsState(
        targetValue = state.rawOffset.x,
        animationSpec = spring(stiffness = Spring.StiffnessHigh), label = "thumbX"
    )
    val thumbY by animateFloatAsState(
        targetValue = state.rawOffset.y,
        animationSpec = spring(stiffness = Spring.StiffnessHigh), label = "thumbY"
    )

    var origin by remember { mutableStateOf(Offset.Zero) }

    Canvas(
        modifier = modifier
            .size(sizeDp)
            .alpha(alpha)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { pos -> origin = pos },
                    onDragEnd   = { origin = Offset.Zero; onRelease() },
                    onDragCancel= { origin = Offset.Zero; onRelease() },
                    onDrag      = { change, dragAmount ->
                        change.consume()
                        val raw  = change.position - origin
                        val dist = raw.getDistance()
                        val clampedDist = dist.coerceAtMost(maxRadius * 0.8f)
                        val angle = atan2(raw.y, raw.x)
                        val clamped = Offset(
                            cos(angle) * clampedDist,
                            sin(angle) * clampedDist
                        )
                        val normalised = Offset(
                            (clamped.x / maxRadius).coerceIn(-1f, 1f),
                            (clamped.y / maxRadius).coerceIn(-1f, 1f)
                        )
                        onMove(StickState(
                            rawOffset  = clamped,
                            normalised = normalised,
                            magnitude  = clampedDist / maxRadius
                        ))
                    }
                )
            }
    ) {
        val center = Offset(size.width / 2f, size.height / 2f)

        // Outer ring
        drawCircle(
            color  = color.copy(alpha = 0.3f),
            radius = maxRadius * 0.95f,
            style  = Stroke(width = 3f)
        )
        // Background fill
        drawCircle(
            color  = Color.Black.copy(alpha = 0.25f),
            radius = maxRadius * 0.93f
        )
        // Direction indicators
        drawDirectionIndicators(center, maxRadius, color)

        // Thumb knob
        val thumbCenter = center + Offset(thumbX, thumbY)
        drawCircle(
            brush  = Brush.radialGradient(
                listOf(color.copy(alpha = 0.9f), color.copy(alpha = 0.5f)),
                center = thumbCenter, radius = maxRadius * 0.38f
            ),
            radius = maxRadius * 0.38f,
            center = thumbCenter
        )
        // Thumb ring
        drawCircle(
            color  = color,
            radius = maxRadius * 0.38f,
            center = thumbCenter,
            style  = Stroke(width = 2.5f)
        )
    }
}

private fun DrawScope.drawDirectionIndicators(center: Offset, maxR: Float, color: Color) {
    val indicatorR = maxR * 0.85f
    val arrowSize  = maxR * 0.10f
    val arrowColor = color.copy(alpha = 0.4f)
    listOf(0f, 90f, 180f, 270f).forEach { deg ->
        val rad  = Math.toRadians(deg.toDouble()).toFloat()
        val tip  = Offset(center.x + cos(rad) * indicatorR, center.y + sin(rad) * indicatorR)
        val back = Offset(center.x + cos(rad) * (indicatorR - arrowSize * 2),
                          center.y + sin(rad) * (indicatorR - arrowSize * 2))
        drawLine(arrowColor, back, tip, strokeWidth = 3f,
                 cap = StrokeCap.Round)
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  ABXY Face Buttons
// ════════════════════════════════════════════════════════════════════════════
@Composable
private fun FaceButtons(
    engine:   EmulatorEngine,
    haptic:   androidx.compose.ui.hapticfeedback.HapticFeedback,
    alpha:    Float,
    modifier: Modifier = Modifier
) {
    val buttons = remember {
        listOf(
            ActionButton("A", ScanCodes.KEY_RETURN,  Color(0xFF4CAF50), 52f),
            ActionButton("B", ScanCodes.KEY_ESCAPE,  Color(0xFFF44336), 52f),
            ActionButton("X", ScanCodes.KEY_SPACE,   Color(0xFF2196F3), 52f),
            ActionButton("Y", ScanCodes.KEY_LSHIFT,  Color(0xFFFF9800), 52f),
        )
    }

    // Diamond layout: Y(top), X(left), B(right), A(bottom)
    Box(modifier = modifier.size(140.dp)) {
        // Y — top
        GameButton(buttons[3], engine, haptic, alpha,
            Modifier.align(Alignment.TopCenter))
        // X — left
        GameButton(buttons[2], engine, haptic, alpha,
            Modifier.align(Alignment.CenterStart))
        // B — right
        GameButton(buttons[1], engine, haptic, alpha,
            Modifier.align(Alignment.CenterEnd))
        // A — bottom
        GameButton(buttons[0], engine, haptic, alpha,
            Modifier.align(Alignment.BottomCenter))
    }
}

@Composable
private fun GameButton(
    btn:      ActionButton,
    engine:   EmulatorEngine,
    haptic:   androidx.compose.ui.hapticfeedback.HapticFeedback,
    alpha:    Float,
    modifier: Modifier = Modifier
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 0.88f else 1f,
        spring(stiffness = Spring.StiffnessMediumLow), label = "btnScale")

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(btn.sizeDp.dp)
            .alpha(alpha)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(CircleShape)
            .background(
                brush = Brush.radialGradient(
                    listOf(btn.color.copy(alpha = 0.85f),
                           btn.color.copy(alpha = 0.55f))
                )
            )
            .pointerInput(btn) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        engine.sendKey(btn.scanCode, true)
                        tryAwaitRelease()
                        pressed = false
                        engine.sendKey(btn.scanCode, false)
                    }
                )
            }
    ) {
        Text(btn.label, color = Color.White, fontSize = 16.sp,
             fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  Shoulder / Trigger Buttons (LB, RB, LT, RT)
// ════════════════════════════════════════════════════════════════════════════
@Composable
private fun ShoulderButtons(
    engine:   EmulatorEngine,
    haptic:   androidx.compose.ui.hapticfeedback.HapticFeedback,
    alpha:    Float,
    modifier: Modifier = Modifier
) {
    Row(
        modifier         = modifier,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Left shoulder group (LT above LB)
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            ShoulderBtn("LT", ScanCodes.KEY_Q, engine, haptic, alpha)
            ShoulderBtn("LB", ScanCodes.KEY_E, engine, haptic, alpha)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ShoulderBtn("⊞", ScanCodes.KEY_BACKSPACE, engine, haptic, alpha, label = "Back")
            ShoulderBtn("⊟", ScanCodes.KEY_TAB,       engine, haptic, alpha, label = "Menu")
        }
        // Right shoulder group (RT above RB)
        Column(verticalArrangement = Arrangement.spacedBy(4.dp),
               horizontalAlignment = Alignment.End) {
            ShoulderBtn("RT", ScanCodes.KEY_LSHIFT, engine, haptic, alpha)
            ShoulderBtn("RB", ScanCodes.KEY_LCTRL,  engine, haptic, alpha)
        }
    }
}

@Composable
private fun ShoulderBtn(
    text:     String,
    scanCode: Int,
    engine:   EmulatorEngine,
    haptic:   androidx.compose.ui.hapticfeedback.HapticFeedback,
    alpha:    Float,
    label:    String = text,
    modifier: Modifier = Modifier
) {
    var pressed by remember { mutableStateOf(false) }
    val bgColor = if (pressed) Color(0xFF444444) else Color(0xFF1A1A2E)

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .width(56.dp)
            .height(28.dp)
            .alpha(alpha)
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor.copy(alpha = 0.8f))
            .pointerInput(scanCode) {
                detectTapGestures(onPress = {
                    pressed = true
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    engine.sendKey(scanCode, true)
                    tryAwaitRelease()
                    pressed = false
                    engine.sendKey(scanCode, false)
                })
            }
    ) {
        Text(label, color = Color.White, fontSize = 11.sp)
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  D-Pad
// ════════════════════════════════════════════════════════════════════════════
@Composable
private fun DPad(
    engine:   EmulatorEngine,
    haptic:   androidx.compose.ui.hapticfeedback.HapticFeedback,
    alpha:    Float,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.size(100.dp).alpha(alpha)) {
        DPadBtn("▲", ScanCodes.KEY_UP,    engine, haptic,
            Modifier.align(Alignment.TopCenter))
        DPadBtn("▼", ScanCodes.KEY_DOWN,  engine, haptic,
            Modifier.align(Alignment.BottomCenter))
        DPadBtn("◄", ScanCodes.KEY_LEFT,  engine, haptic,
            Modifier.align(Alignment.CenterStart))
        DPadBtn("►", ScanCodes.KEY_RIGHT, engine, haptic,
            Modifier.align(Alignment.CenterEnd))
    }
}

@Composable
private fun DPadBtn(
    arrow:    String,
    scanCode: Int,
    engine:   EmulatorEngine,
    haptic:   androidx.compose.ui.hapticfeedback.HapticFeedback,
    modifier: Modifier = Modifier
) {
    var pressed by remember { mutableStateOf(false) }
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(32.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(
                if (pressed) Color(0xFF333355) else Color(0xFF1A1A2E).copy(alpha = 0.75f)
            )
            .pointerInput(scanCode) {
                detectTapGestures(onPress = {
                    pressed = true
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    engine.sendKey(scanCode, true)
                    tryAwaitRelease()
                    pressed = false
                    engine.sendKey(scanCode, false)
                })
            }
    ) {
        Text(arrow, color = Color.White, fontSize = 14.sp)
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  HUD overlay (FPS counter, gyro toggle, save state button)
// ════════════════════════════════════════════════════════════════════════════
@Composable
private fun HudOverlay(
    engine:       EmulatorEngine,
    gyroActive:   Boolean,
    onGyroToggle: () -> Unit,
    modifier:     Modifier = Modifier
) {
    val fps by engine.fps.collectAsState()

    Column(
        modifier              = modifier,
        horizontalAlignment   = Alignment.End,
        verticalArrangement   = Arrangement.spacedBy(6.dp)
    ) {
        // FPS counter
        Surface(
            color  = Color.Black.copy(alpha = 0.5f),
            shape  = RoundedCornerShape(6.dp)
        ) {
            val fpsColor = when {
                fps >= 55f -> Color(0xFF4CAF50)
                fps >= 30f -> Color(0xFFFF9800)
                else       -> Color(0xFFF44336)
            }
            Text(
                text     = "${fps.toInt()} FPS",
                color    = fpsColor,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }

        // Gyro toggle
        Surface(
            color   = if (gyroActive) Color(0xFF1565C0).copy(alpha = 0.8f)
                      else Color.Black.copy(alpha = 0.5f),
            shape   = RoundedCornerShape(6.dp),
            onClick = onGyroToggle
        ) {
            Text(
                text     = if (gyroActive) "GYRO ON" else "GYRO",
                color    = Color.White,
                fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}
