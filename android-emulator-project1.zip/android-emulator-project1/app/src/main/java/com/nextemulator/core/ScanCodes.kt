package com.nextemulator.core

/**
 * Windows keyboard scan codes (Set 1) used by DirectInput / WinAPI.
 * These are injected directly into the virtual keyboard device.
 */
object ScanCodes {
    const val KEY_ESCAPE    = 0x01
    const val KEY_1         = 0x02
    const val KEY_2         = 0x03
    const val KEY_3         = 0x04
    const val KEY_4         = 0x05
    const val KEY_5         = 0x06
    const val KEY_6         = 0x07
    const val KEY_7         = 0x08
    const val KEY_8         = 0x09
    const val KEY_9         = 0x0A
    const val KEY_0         = 0x0B
    const val KEY_TAB       = 0x0F
    const val KEY_Q         = 0x10
    const val KEY_W         = 0x11
    const val KEY_E         = 0x12
    const val KEY_R         = 0x13
    const val KEY_T         = 0x14
    const val KEY_Y         = 0x15
    const val KEY_U         = 0x16
    const val KEY_I         = 0x17
    const val KEY_O         = 0x18
    const val KEY_P         = 0x19
    const val KEY_A         = 0x1E
    const val KEY_S         = 0x1F
    const val KEY_D         = 0x20
    const val KEY_F         = 0x21
    const val KEY_G         = 0x22
    const val KEY_H         = 0x23
    const val KEY_J         = 0x24
    const val KEY_K         = 0x25
    const val KEY_L         = 0x26
    const val KEY_RETURN    = 0x1C
    const val KEY_LSHIFT    = 0x2A
    const val KEY_RSHIFT    = 0x36
    const val KEY_LCTRL     = 0x1D
    const val KEY_LALT      = 0x38
    const val KEY_SPACE     = 0x39
    const val KEY_BACKSPACE = 0x0E
    const val KEY_F1        = 0x3B
    const val KEY_F2        = 0x3C
    const val KEY_F3        = 0x3D
    const val KEY_F4        = 0x3E
    const val KEY_F5        = 0x3F
    const val KEY_F9        = 0x43
    const val KEY_UP        = 0xC8 // extended
    const val KEY_DOWN      = 0xD0 // extended
    const val KEY_LEFT      = 0xCB // extended
    const val KEY_RIGHT     = 0xCD // extended
    const val KEY_INSERT    = 0xD2
    const val KEY_DELETE    = 0xD3
    const val KEY_HOME      = 0xC7
    const val KEY_END       = 0xCF
    const val KEY_PAGEUP    = 0xC9
    const val KEY_PAGEDOWN  = 0xD1

    // XInput axes (virtual axis IDs sent to nativeSendAxisEvent)
    const val AXIS_LEFT_X   = 0
    const val AXIS_LEFT_Y   = 1
    const val AXIS_RIGHT_X  = 2
    const val AXIS_RIGHT_Y  = 3
    const val AXIS_LT       = 4
    const val AXIS_RT       = 5

    // XInput buttons (mapped to scan codes for compatibility)
    const val XINPUT_A      = KEY_RETURN
    const val XINPUT_B      = KEY_ESCAPE
    const val XINPUT_X      = KEY_SPACE
    const val XINPUT_Y      = KEY_LSHIFT
    const val XINPUT_LB     = KEY_Q
    const val XINPUT_RB     = KEY_E
    const val XINPUT_START  = KEY_F9
    const val XINPUT_BACK   = KEY_TAB
}
