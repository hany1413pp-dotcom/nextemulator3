package com.nextemulator.modding

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream

/**
 * ModManager — runtime mod injection and management.
 *
 * Supports:
 *  - HD texture packs (loose files or ZIP archives)
 *  - Cheat tables (.CT XML) parsed and applied via memory writes
 *  - OBB patches (Android expansion file replacement)
 *  - Graphic script injection (ReShade-style config files)
 *
 * Mods are applied to a game's Wine prefix without touching core emulator
 * files, making them fully reversible per-game.
 */
@Serializable
data class Mod(
    val id:          String,
    val name:        String,
    val type:        ModType,
    val sourcePath:  String,
    val gameId:      String,
    val enabled:     Boolean = true,
    val description: String  = "",
    val version:     String  = "1.0"
)

@Serializable
enum class ModType {
    HD_TEXTURE,
    CHEAT_TABLE,
    OBB_PATCH,
    GRAPHIC_SCRIPT,
    DLL_OVERRIDE
}

class ModManager(private val context: Context) {

    companion object { private const val TAG = "ModManager" }

    private val json   = Json { prettyPrint = true; ignoreUnknownKeys = true }
    private val modDir get() = File(context.filesDir, "mods").also { it.mkdirs() }

    // ── Mod catalogue ─────────────────────────────────────────────────────────
    suspend fun listMods(gameId: String): List<Mod> = withContext(Dispatchers.IO) {
        File(modDir, gameId).listFiles { f -> f.extension == "json" }
            ?.mapNotNull { f -> runCatching { json.decodeFromString<Mod>(f.readText()) }.getOrNull() }
            ?: emptyList()
    }

    suspend fun saveMod(mod: Mod) = withContext(Dispatchers.IO) {
        val dir = File(modDir, mod.gameId).also { it.mkdirs() }
        File(dir, "${mod.id}.json").writeText(json.encodeToString(Mod.serializer(), mod))
    }

    suspend fun deleteMod(gameId: String, modId: String) = withContext(Dispatchers.IO) {
        File(modDir, "$gameId/$modId.json").delete()
        File(modDir, "$gameId/$modId").deleteRecursively()
    }

    // ── Mod installation ──────────────────────────────────────────────────────
    /**
     * Install a mod from a ZIP archive or loose directory.
     * Extracts to mods/<gameId>/<modId>/ then registers the mod.
     */
    suspend fun install(
        gameId:     String,
        name:       String,
        type:       ModType,
        inputStream: InputStream
    ): Mod = withContext(Dispatchers.IO) {
        val id      = name.lowercase().replace(Regex("[^a-z0-9]"), "_") + "_${System.currentTimeMillis()}"
        val destDir = File(modDir, "$gameId/$id").also { it.mkdirs() }

        ZipInputStream(inputStream).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) {
                    val outFile = File(destDir, entry.name)
                    outFile.parentFile?.mkdirs()
                    outFile.outputStream().use { zip.copyTo(it) }
                }
                entry = zip.nextEntry
            }
        }

        Log.i(TAG, "Installed mod '$name' ($type) → $destDir")
        Mod(id = id, name = name, type = type, sourcePath = destDir.absolutePath, gameId = gameId)
            .also { saveMod(it) }
    }

    // ── Runtime injection ─────────────────────────────────────────────────────
    /**
     * Apply all enabled mods for a game to its Wine prefix.
     * Called immediately before nativeStart() so mods are active from frame 1.
     */
    suspend fun applyMods(gameId: String, winePrefix: String) = withContext(Dispatchers.IO) {
        val mods = listMods(gameId).filter { it.enabled }
        Log.i(TAG, "Applying ${mods.size} mod(s) for game $gameId")

        mods.forEach { mod ->
            when (mod.type) {
                ModType.HD_TEXTURE     -> applyTextureOverride(mod, winePrefix)
                ModType.DLL_OVERRIDE   -> applyDllOverride(mod, winePrefix)
                ModType.GRAPHIC_SCRIPT -> applyGraphicScript(mod, winePrefix)
                ModType.OBB_PATCH      -> applyObbPatch(mod, winePrefix)
                ModType.CHEAT_TABLE    -> Log.d(TAG, "Cheat table '${mod.name}' will activate at runtime")
            }
        }
    }

    private fun applyTextureOverride(mod: Mod, winePrefix: String) {
        // Symlink or copy HD textures into the game's texture directory
        val src  = File(mod.sourcePath)
        val dest = File(winePrefix, "drive_c/textures/${mod.id}")
        if (!dest.exists()) src.copyRecursively(dest, overwrite = true)
        Log.d(TAG, "Texture override applied: ${mod.name}")
    }

    private fun applyDllOverride(mod: Mod, winePrefix: String) {
        // Copy .dll files into the game directory and register in Wine registry
        File(mod.sourcePath).listFiles { f -> f.extension == "dll" }?.forEach { dll ->
            val dest = File(winePrefix, "drive_c/windows/system32/${dll.name}")
            dll.copyTo(dest, overwrite = true)
        }
        Log.d(TAG, "DLL override applied: ${mod.name}")
    }

    private fun applyGraphicScript(mod: Mod, winePrefix: String) {
        // Copy ReShade.ini / custom GLSL shaders into the game directory
        File(mod.sourcePath).copyRecursively(
            File(winePrefix, "drive_c/reshade_${mod.id}"), overwrite = true)
        Log.d(TAG, "Graphic script applied: ${mod.name}")
    }

    private fun applyObbPatch(mod: Mod, winePrefix: String) {
        // Replace OBB data files in the prefix
        File(mod.sourcePath).copyRecursively(
            File(winePrefix, "drive_c/obb_${mod.id}"), overwrite = true)
        Log.d(TAG, "OBB patch applied: ${mod.name}")
    }
}
