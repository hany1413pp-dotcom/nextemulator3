package com.nextemulator.core

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File

/**
 * GameProfile — per-game configuration container.
 *
 * Stores the game's execution path, Wine prefix directory, optimal
 * environment variables, controller layout, and DRS target FPS.
 * Persisted as JSON in the app's filesDir.
 */
@Serializable
data class GameProfile(
    val id:           String,
    val name:         String,
    val execPath:     String,
    val coverArtPath: String    = "",
    val winePrefix:   String    = "",
    val targetFps:    Int       = 60,
    val resolutionScale: Float  = 1.0f,
    val dxvkEnabled:  Boolean   = true,
    val esyncEnabled: Boolean   = true,
    val fsyncEnabled: Boolean   = false,
    val envVars:      Map<String, String> = defaultEnvVars(),
    val controllerConfig: Map<String, String> = emptyMap(),
    val lastPlayed:   Long      = 0L,
    val playTimeMs:   Long      = 0L
)

fun defaultEnvVars(): Map<String, String> = mapOf(
    // DXVK + Wine optimisations
    "DXVK_HUD"                     to "fps,memory",
    "DXVK_ASYNC"                   to "1",              // async shader compile
    "DXVK_STATE_CACHE_PATH"        to "{CACHE_DIR}",     // replaced at runtime
    "DXVK_LOG_LEVEL"               to "none",
    "WINE_LARGE_ADDRESS_AWARE"     to "1",
    "WINEDLLOVERRIDES"             to "mscoree,mshtml=",
    "WINE_FULLSCREEN_FSR"          to "1",               // AMD FSR in Wine
    "WINE_FULLSCREEN_FSR_STRENGTH" to "2",
    // Mesa/Vulkan — tell it to use the Mali Vulkan driver
    "VK_ICD_FILENAMES"             to "/vendor/etc/vulkan/icd.d/mali_icd.json",
    "GALLIUM_DRIVER"               to "zink",            // Vulkan-on-Mesa path
    // Oboe audio backend
    "WINEDEBUG"                    to "-all",
    // Performance
    "MALLOC_TRIM_THRESHOLD_"       to "131072",
    "MALLOC_MMAP_THRESHOLD_"       to "131072",
)

// ── Repository ────────────────────────────────────────────────────────────────
class GameProfileRepository(private val context: Context) {

    private val json   = Json { prettyPrint = true; ignoreUnknownKeys = true }
    private val dir    get() = File(context.filesDir, "profiles").also { it.mkdirs() }

    suspend fun loadAll(): List<GameProfile> = withContext(Dispatchers.IO) {
        dir.listFiles { f -> f.extension == "json" }
            ?.mapNotNull { f -> runCatching { json.decodeFromString<GameProfile>(f.readText()) }.getOrNull() }
            ?.sortedByDescending { it.lastPlayed }
            ?: emptyList()
    }

    suspend fun save(profile: GameProfile) = withContext(Dispatchers.IO) {
        File(dir, "${profile.id}.json").writeText(json.encodeToString(GameProfile.serializer(), profile))
    }

    suspend fun delete(id: String) = withContext(Dispatchers.IO) {
        File(dir, "$id.json").delete()
    }

    suspend fun findById(id: String): GameProfile? = withContext(Dispatchers.IO) {
        runCatching { json.decodeFromString<GameProfile>(File(dir, "$id.json").readText()) }.getOrNull()
    }

    /**
     * Auto-detect optimal settings for a game based on its executable path.
     * Checks known game hashes against a bundled compatibility database.
     */
    fun autoDetectSettings(execPath: String): GameProfile {
        val name    = File(execPath).nameWithoutExtension
        val id      = name.lowercase().replace(Regex("[^a-z0-9]"), "_")
        val prefix  = File(context.filesDir, "wineprefix/$id").absolutePath

        // Heuristic: if it's a D3D11/D3D9 game, enable DXVK; ELF → native
        val isDx = execPath.endsWith(".exe", ignoreCase = true)

        return GameProfile(
            id           = id,
            name         = name,
            execPath     = execPath,
            winePrefix   = prefix,
            dxvkEnabled  = isDx,
            targetFps    = 60,
            envVars      = defaultEnvVars().toMutableMap().apply {
                this["WINEPREFIX"] = prefix
            }
        )
    }
}
