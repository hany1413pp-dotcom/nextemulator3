/**
 * NativeEmulatorCore.cpp
 *
 * JNI backbone: initialises the DBT engine, Vulkan context, Oboe audio,
 * and drives the main emulation loop.  Designed for the Unisoc UMS9230H
 * (2x Cortex-A75 "big" + 6x Cortex-A55 "little") with Mali-G57 GPU.
 */

#include <jni.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <pthread.h>
#include <sched.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <unistd.h>
#include <atomic>
#include <thread>
#include <vector>
#include <memory>
#include <string>

#include "dbt/x86_64_decoder.h"
#include "dbt/arm64_emitter.h"
#include "dbt/translation_cache.h"
#include "vulkan/VulkanRenderer.h"
#include "vulkan/ShaderCache.h"
#include "vulkan/DynamicResolutionScaler.h"
#include "audio/OboeAudioEngine.h"
#include "memory/MemoryMapper.h"
#include "memory/SaveStateManager.h"
#include "network/VirtualLAN.h"

#define LOG_TAG "NextEmulator"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)

// ── CPU topology ──────────────────────────────────────────────────────────────
// Unisoc UMS9230H: cores 0-1 = A75 (big), cores 2-7 = A55 (little)
static constexpr int BIG_CORE_0   = 0;
static constexpr int BIG_CORE_1   = 1;
static constexpr int LITTLE_START = 2;
static constexpr int LITTLE_END   = 7;

// ── Global state ──────────────────────────────────────────────────────────────
struct EmulatorState {
    std::unique_ptr<dbt::X86_64Decoder>    decoder;
    std::unique_ptr<dbt::Arm64Emitter>     emitter;
    std::unique_ptr<dbt::TranslationCache> tcache;
    std::unique_ptr<VulkanRenderer>        renderer;
    std::unique_ptr<ShaderCache>           shaderCache;
    std::unique_ptr<DynamicResolutionScaler> drs;
    std::unique_ptr<OboeAudioEngine>       audio;
    std::unique_ptr<MemoryMapper>          memory;
    std::unique_ptr<SaveStateManager>      saveState;
    std::unique_ptr<VirtualLAN>            vlan;

    ANativeWindow*   window   = nullptr;
    std::atomic<bool> running  {false};
    std::atomic<bool> paused   {false};

    // JVM references for callbacks
    JavaVM*  jvm       = nullptr;
    jobject  callbackObj = nullptr;
    jmethodID onFpsUpdate = nullptr;
    jmethodID onThermalWarning = nullptr;
};

static EmulatorState g_emu;

// ── Thread affinity helpers ───────────────────────────────────────────────────
static void pin_to_big_cores(pthread_t tid) {
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(BIG_CORE_0, &cpuset);
    CPU_SET(BIG_CORE_1, &cpuset);
    pthread_setaffinity_np(tid, sizeof(cpu_set_t), &cpuset);
    // Raise scheduling priority for translation thread
    struct sched_param sp { .sched_priority = sched_get_priority_max(SCHED_FIFO) };
    pthread_setschedparam(tid, SCHED_FIFO, &sp);
}

static void pin_to_little_cores(pthread_t tid) {
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    for (int c = LITTLE_START; c <= LITTLE_END; ++c)
        CPU_SET(c, &cpuset);
    pthread_setaffinity_np(tid, sizeof(cpu_set_t), &cpuset);
}

// ── Translation (DBT) loop — pinned to A75 big cores ─────────────────────────
static void* translation_loop(void*) {
    prctl(PR_SET_NAME, "emu-dbt-big", 0, 0, 0);
    pin_to_big_cores(pthread_self());
    LOGI("DBT loop started on big cores (A75)");

    while (g_emu.running.load(std::memory_order_acquire)) {
        if (g_emu.paused.load()) {
            usleep(5000);
            continue;
        }
        // Fetch next x86_64 instruction block
        auto block = g_emu.decoder->fetch_next_block();
        if (!block) continue;

        // Check translation cache
        auto cached = g_emu.tcache->lookup(block->guest_addr);
        if (cached) {
            cached->execute();
            continue;
        }

        // Translate → ARM64 and cache
        auto arm_code = g_emu.emitter->translate(*block);
        g_emu.tcache->insert(block->guest_addr, std::move(arm_code));
        g_emu.tcache->get_and_execute(block->guest_addr);
    }
    return nullptr;
}

// ── Render loop — runs on little cores (Mali-G57 via Vulkan) ─────────────────
static void* render_loop(void*) {
    prctl(PR_SET_NAME, "emu-render", 0, 0, 0);
    // Render thread stays on a little core; GPU is independent
    pin_to_little_cores(pthread_self());
    LOGI("Render loop started");

    uint32_t frameCount = 0;
    auto lastFpsTime = std::chrono::steady_clock::now();

    while (g_emu.running.load(std::memory_order_acquire)) {
        if (g_emu.paused.load() || !g_emu.window) {
            usleep(8333); // ~120 Hz idle
            continue;
        }

        // Dynamic Resolution Scaling decision
        float scale = g_emu.drs->current_scale();

        // Submit frame to Vulkan
        g_emu.renderer->begin_frame();
        g_emu.renderer->render_guest_framebuffer(scale);
        g_emu.renderer->end_frame();

        frameCount++;
        auto now = std::chrono::steady_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastFpsTime).count();
        if (elapsed >= 1000) {
            float fps = frameCount * 1000.0f / elapsed;
            frameCount  = 0;
            lastFpsTime = now;

            // Report FPS back to Kotlin via JNI callback
            JNIEnv* env;
            if (g_emu.jvm && g_emu.jvm->AttachCurrentThread(&env, nullptr) == JNI_OK) {
                env->CallVoidMethod(g_emu.callbackObj, g_emu.onFpsUpdate, (jfloat)fps);
                g_emu.jvm->DetachCurrentThread();
            }

            // Dynamic resolution: adjust if FPS drops
            g_emu.drs->tick(fps);
        }
    }
    return nullptr;
}

// ── I/O loop — little cores ───────────────────────────────────────────────────
static void* io_loop(void*) {
    prctl(PR_SET_NAME, "emu-io", 0, 0, 0);
    pin_to_little_cores(pthread_self());
    while (g_emu.running.load(std::memory_order_acquire)) {
        g_emu.memory->process_pending_io();
        usleep(1000);
    }
    return nullptr;
}

// ════════════════════════════════════════════════════════════════════════════
//  JNI Exports
// ════════════════════════════════════════════════════════════════════════════
extern "C" {

// ── Init ──────────────────────────────────────────────────────────────────────
JNIEXPORT jint JNICALL
Java_com_nextemulator_core_EmulatorEngine_nativeInit(
        JNIEnv* env, jobject thiz,
        jstring cacheDirJ, jstring prefixDirJ)
{
    env->GetJavaVM(&g_emu.jvm);
    g_emu.callbackObj = env->NewGlobalRef(thiz);

    jclass clazz = env->GetObjectClass(thiz);
    g_emu.onFpsUpdate      = env->GetMethodID(clazz, "onFpsUpdate", "(F)V");
    g_emu.onThermalWarning = env->GetMethodID(clazz, "onThermalWarning", "()V");

    const char* cacheDir  = env->GetStringUTFChars(cacheDirJ, nullptr);
    const char* prefixDir = env->GetStringUTFChars(prefixDirJ, nullptr);

    LOGI("Initialising NextEmulator core — cache=%s prefix=%s", cacheDir, prefixDir);

    // Translation cache (128MB of JIT code arena, locked in RAM)
    g_emu.tcache     = std::make_unique<dbt::TranslationCache>(128 * 1024 * 1024);
    g_emu.decoder    = std::make_unique<dbt::X86_64Decoder>();
    g_emu.emitter    = std::make_unique<dbt::Arm64Emitter>(g_emu.tcache.get());

    // Memory mapper — 3 GB guest virtual address space
    g_emu.memory     = std::make_unique<MemoryMapper>(3ULL * 1024 * 1024 * 1024);

    // Shader cache (Mali-G57 SPIR-V pre-compiled blobs)
    g_emu.shaderCache = std::make_unique<ShaderCache>(cacheDir);
    g_emu.drs         = std::make_unique<DynamicResolutionScaler>(/*target_fps=*/60);

    // Audio
    g_emu.audio      = std::make_unique<OboeAudioEngine>();
    g_emu.audio->start();

    // Save state
    g_emu.saveState  = std::make_unique<SaveStateManager>(prefixDir, g_emu.memory.get());

    // Virtual LAN
    g_emu.vlan       = std::make_unique<VirtualLAN>();

    env->ReleaseStringUTFChars(cacheDirJ,  cacheDir);
    env->ReleaseStringUTFChars(prefixDirJ, prefixDir);

    LOGI("Core init complete");
    return 0;
}

// ── Surface attach ────────────────────────────────────────────────────────────
JNIEXPORT void JNICALL
Java_com_nextemulator_core_EmulatorEngine_nativeSurfaceCreated(
        JNIEnv* env, jobject, jobject surface)
{
    g_emu.window = ANativeWindow_fromSurface(env, surface);
    if (!g_emu.window) {
        LOGE("Failed to get ANativeWindow");
        return;
    }
    g_emu.renderer = std::make_unique<VulkanRenderer>(
        g_emu.window, g_emu.shaderCache.get());
    g_emu.renderer->init();
    LOGI("Vulkan surface initialised (%dx%d)",
         ANativeWindow_getWidth(g_emu.window),
         ANativeWindow_getHeight(g_emu.window));
}

JNIEXPORT void JNICALL
Java_com_nextemulator_core_EmulatorEngine_nativeSurfaceDestroyed(JNIEnv*, jobject) {
    if (g_emu.renderer) g_emu.renderer->shutdown();
    if (g_emu.window)   { ANativeWindow_release(g_emu.window); g_emu.window = nullptr; }
}

// ── Start / stop ──────────────────────────────────────────────────────────────
JNIEXPORT jint JNICALL
Java_com_nextemulator_core_EmulatorEngine_nativeStart(
        JNIEnv* env, jobject, jstring execPathJ)
{
    const char* execPath = env->GetStringUTFChars(execPathJ, nullptr);
    LOGI("Starting execution: %s", execPath);

    if (!g_emu.decoder->load_executable(execPath)) {
        LOGE("Failed to load: %s", execPath);
        env->ReleaseStringUTFChars(execPathJ, execPath);
        return -1;
    }
    env->ReleaseStringUTFChars(execPathJ, execPath);

    g_emu.running.store(true);

    // Spawn threads — DBT on big cores, render+IO on little cores
    pthread_t dbt_thread, render_thread, io_thread;
    pthread_create(&dbt_thread,    nullptr, translation_loop, nullptr);
    pthread_create(&render_thread, nullptr, render_loop,      nullptr);
    pthread_create(&io_thread,     nullptr, io_loop,          nullptr);

    pthread_detach(dbt_thread);
    pthread_detach(render_thread);
    pthread_detach(io_thread);

    return 0;
}

JNIEXPORT void JNICALL
Java_com_nextemulator_core_EmulatorEngine_nativeStop(JNIEnv*, jobject) {
    g_emu.running.store(false);
    if (g_emu.audio) g_emu.audio->stop();
    LOGI("Emulator stopped");
}

JNIEXPORT void JNICALL
Java_com_nextemulator_core_EmulatorEngine_nativePause(JNIEnv*, jobject, jboolean paused) {
    g_emu.paused.store((bool)paused);
}

// ── Input injection ───────────────────────────────────────────────────────────
JNIEXPORT void JNICALL
Java_com_nextemulator_core_EmulatorEngine_nativeSendKeyEvent(
        JNIEnv*, jobject, jint scanCode, jboolean pressed)
{
    g_emu.decoder->inject_key_event((uint32_t)scanCode, (bool)pressed);
}

JNIEXPORT void JNICALL
Java_com_nextemulator_core_EmulatorEngine_nativeSendMouseDelta(
        JNIEnv*, jobject, jfloat dx, jfloat dy)
{
    g_emu.decoder->inject_mouse_delta(dx, dy);
}

JNIEXPORT void JNICALL
Java_com_nextemulator_core_EmulatorEngine_nativeSendAxisEvent(
        JNIEnv*, jobject, jint axis, jfloat value)
{
    g_emu.decoder->inject_axis(axis, value);
}

// ── Save state ────────────────────────────────────────────────────────────────
JNIEXPORT jboolean JNICALL
Java_com_nextemulator_core_EmulatorEngine_nativeSaveState(
        JNIEnv* env, jobject, jint slot)
{
    g_emu.paused.store(true);
    bool ok = g_emu.saveState->save(slot);
    g_emu.paused.store(false);
    return (jboolean)ok;
}

JNIEXPORT jboolean JNICALL
Java_com_nextemulator_core_EmulatorEngine_nativeLoadState(
        JNIEnv* env, jobject, jint slot)
{
    g_emu.paused.store(true);
    bool ok = g_emu.saveState->load(slot);
    g_emu.paused.store(false);
    return (jboolean)ok;
}

// ── Destroy ───────────────────────────────────────────────────────────────────
JNIEXPORT void JNICALL
Java_com_nextemulator_core_EmulatorEngine_nativeDestroy(JNIEnv* env, jobject) {
    g_emu.running.store(false);
    if (g_emu.audio)     g_emu.audio->stop();
    if (g_emu.renderer)  g_emu.renderer->shutdown();
    if (g_emu.window)    ANativeWindow_release(g_emu.window);
    if (g_emu.callbackObj) env->DeleteGlobalRef(g_emu.callbackObj);
    g_emu = EmulatorState{};
    LOGI("EmulatorState destroyed and memory freed");
}

} // extern "C"
