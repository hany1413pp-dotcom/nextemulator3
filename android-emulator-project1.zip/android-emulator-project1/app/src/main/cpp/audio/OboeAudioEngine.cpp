/**
 * OboeAudioEngine.cpp — Google Oboe ultra-low-latency audio backend.
 *
 * Target: < 10 ms round-trip latency (EXCLUSIVE AAudio mode).
 * Fallback: OpenSL ES at ~20 ms (for older Android kernels).
 */
#include "OboeAudioEngine.h"
#include <android/log.h>
#include <cstring>
#include <algorithm>

#define LOG_TAG "OboeAudio"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

OboeAudioEngine::OboeAudioEngine() {
    memset(m_ring, 0, sizeof(m_ring));
}

OboeAudioEngine::~OboeAudioEngine() { stop(); }

bool OboeAudioEngine::start() {
    oboe::AudioStreamBuilder builder;
    builder.setDirection(oboe::Direction::Output)
           .setPerformanceMode(oboe::PerformanceMode::LowLatency)
           .setSharingMode(oboe::SharingMode::Exclusive)      // lowest latency
           .setFormat(oboe::AudioFormat::I16)
           .setChannelCount(oboe::ChannelCount::Stereo)
           .setSampleRate(48000)
           .setFramesPerDataCallback(256)                     // ~5.3 ms @ 48kHz
           .setDataCallback(this);

    // Prefer AAudio (Android 8.1+), fallback to OpenSL ES
    builder.setAudioApi(oboe::AudioApi::AAudio);

    oboe::Result result = builder.openStream(m_stream);
    if (result != oboe::Result::OK) {
        LOGE("Failed to open AAudio stream: %s — retrying with OpenSL ES",
             oboe::convertToText(result));
        builder.setAudioApi(oboe::AudioApi::OpenSLES);
        result = builder.openStream(m_stream);
        if (result != oboe::Result::OK) {
            LOGE("OpenSL ES also failed: %s", oboe::convertToText(result));
            return false;
        }
    }

    result = m_stream->requestStart();
    if (result != oboe::Result::OK) {
        LOGE("Failed to start audio stream: %s", oboe::convertToText(result));
        return false;
    }

    LOGI("Audio started: %s, latency=%lld ms, frameSize=%d",
         m_stream->getAudioApi() == oboe::AudioApi::AAudio ? "AAudio" : "OpenSL ES",
         (long long)(m_stream->getBufferSizeInFrames() * 1000 / m_stream->getSampleRate()),
         m_stream->getFramesPerDataCallback());
    return true;
}

void OboeAudioEngine::stop() {
    if (m_stream) {
        m_stream->requestStop();
        m_stream->close();
        m_stream.reset();
        LOGI("Audio stream stopped");
    }
}

// Called from guest audio thread — copies PCM into ring buffer
void OboeAudioEngine::push_samples(const int16_t* data, int frames) {
    int write = m_write_pos.load(std::memory_order_relaxed);
    int free  = frames_free();
    int copy  = std::min(frames, free);

    for (int i = 0; i < copy; i++) {
        int pos = (write + i) & (RING_FRAMES - 1);
        m_ring[pos * 2 + 0] = data[i * 2 + 0]; // L
        m_ring[pos * 2 + 1] = data[i * 2 + 1]; // R
    }
    m_write_pos.store((write + copy) & (RING_FRAMES - 1), std::memory_order_release);
}

// Oboe audio callback — runs on dedicated high-priority audio thread
oboe::DataCallbackResult OboeAudioEngine::onAudioReady(
    oboe::AudioStream* /*stream*/, void* audioData, int32_t numFrames)
{
    auto* out = static_cast<int16_t*>(audioData);
    int available = frames_available();
    int fill      = std::min(numFrames, available);
    int read      = m_read_pos.load(std::memory_order_relaxed);

    for (int i = 0; i < fill; i++) {
        int pos = (read + i) & (RING_FRAMES - 1);
        out[i * 2 + 0] = m_ring[pos * 2 + 0];
        out[i * 2 + 1] = m_ring[pos * 2 + 1];
    }
    // Silence any remaining frames (buffer underrun)
    if (fill < numFrames)
        memset(out + fill * 2, 0, (numFrames - fill) * 2 * sizeof(int16_t));

    m_read_pos.store((read + fill) & (RING_FRAMES - 1), std::memory_order_release);
    return oboe::DataCallbackResult::Continue;
}

int OboeAudioEngine::frames_available() const {
    int w = m_write_pos.load(std::memory_order_acquire);
    int r = m_read_pos.load(std::memory_order_relaxed);
    return (w - r + RING_FRAMES) & (RING_FRAMES - 1);
}

int OboeAudioEngine::frames_free() const {
    return RING_FRAMES - 1 - frames_available();
}
