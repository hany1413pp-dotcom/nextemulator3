#pragma once
#include <oboe/Oboe.h>
#include <memory>
#include <vector>
#include <mutex>
#include <atomic>

/**
 * OboeAudioEngine — zero-latency audio via Google Oboe.
 *
 * Uses AAudio backend (primary) with OpenSL ES fallback.
 * Targets EXCLUSIVE low-latency mode with 48 kHz / 16-bit stereo output.
 * Guest audio is mixed into a ring buffer consumed by the Oboe callback.
 */
class OboeAudioEngine : public oboe::AudioStreamDataCallback {
public:
    OboeAudioEngine();
    ~OboeAudioEngine() override;

    bool start();
    void stop();

    // Queue PCM samples from the guest audio subsystem
    void push_samples(const int16_t* data, int frames);

    // Oboe callback — called on the audio thread (high-priority, little core)
    oboe::DataCallbackResult onAudioReady(
        oboe::AudioStream* stream,
        void* audioData,
        int32_t numFrames) override;

private:
    std::shared_ptr<oboe::AudioStream> m_stream;

    // Lock-free ring buffer (power-of-two frames)
    static constexpr int RING_FRAMES = 4096;
    int16_t m_ring[RING_FRAMES * 2]; // stereo
    std::atomic<int> m_write_pos{0};
    std::atomic<int> m_read_pos{0};

    int frames_available() const;
    int frames_free() const;
};
