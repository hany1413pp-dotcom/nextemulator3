#pragma once
#include <string>
#include <memory>

class MemoryMapper;

/**
 * SaveStateManager — instant save/load snapshots.
 *
 * Dumps the active guest RAM allocation to a compressed LZ4 file.
 * Target: < 500 ms save time for 1.3 GB of guest RAM.
 */
class SaveStateManager {
public:
    SaveStateManager(const std::string& saveDir, MemoryMapper* memory);
    ~SaveStateManager();

    bool save(int slot);
    bool load(int slot);
    bool slot_exists(int slot) const;

private:
    std::string  m_saveDir;
    MemoryMapper* m_memory;

    std::string slot_path(int slot) const;
    bool compress_and_write(int slot);
    bool read_and_decompress(int slot);
};
