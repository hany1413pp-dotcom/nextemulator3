#pragma once
#include <cstdint>
#include <cstddef>
#include <string>
#include <memory>

/**
 * MemoryMapper — manages the guest virtual address space via mmap.
 *
 * Implements:
 *  - 3 GB guest address space reserved with a single mmap reservation
 *  - Per-region protection flags mirroring Windows VirtualAlloc semantics
 *  - Demand-paging via userfaultfd or SIGSEGV handler
 *  - Pending I/O queue processed on the little-core I/O thread
 */
class MemoryMapper {
public:
    explicit MemoryMapper(size_t guest_va_size);
    ~MemoryMapper();

    // Map a region: returns host pointer or nullptr on failure
    void* map_region(uint64_t guest_va, size_t size, int prot);

    // Unmap a guest region
    void  unmap_region(uint64_t guest_va, size_t size);

    // Read/write guest memory from the emulator core
    bool read_guest(uint64_t guest_va, void* dst, size_t len);
    bool write_guest(uint64_t guest_va, const void* src, size_t len);

    // Mount a file into the guest VA (zero-copy .iso/.chd block device)
    bool map_file(const std::string& path, uint64_t guest_va);

    // Process any pending I/O operations (called from I/O thread)
    void process_pending_io();

    // Total host memory committed (bytes)
    size_t committed_bytes() const;

    // Host base pointer (for direct JIT code access)
    uint8_t* host_base() const { return m_host_base; }

private:
    uint8_t* m_host_base    = nullptr;
    size_t   m_va_size      = 0;
    size_t   m_committed    = 0;

    struct Region;
    struct Impl;
    std::unique_ptr<Impl> m_impl;
};
