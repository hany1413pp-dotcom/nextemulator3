/**
 * MemoryMapper.cpp — guest virtual address space management.
 *
 * Uses a single large PROT_NONE reservation then commits pages on demand,
 * keeping RSS (Resident Set Size) well below the 6 GB physical limit.
 */
#include "MemoryMapper.h"
#include <android/log.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstring>
#include <map>
#include <mutex>
#include <queue>

#define LOG_TAG "MemMapper"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

struct MemoryMapper::Region {
    uint64_t guest_va;
    size_t   size;
    int      prot;
    int      fd; // -1 if anonymous
};

struct MemoryMapper::Impl {
    std::map<uint64_t, Region> regions;
    std::mutex regions_mtx;

    struct PendingIO { uint64_t va; size_t len; bool is_write; };
    std::queue<PendingIO> io_queue;
    std::mutex io_mtx;
};

MemoryMapper::MemoryMapper(size_t guest_va_size)
    : m_va_size(guest_va_size), m_impl(std::make_unique<Impl>())
{
    // Reserve the entire guest address space as PROT_NONE
    m_host_base = (uint8_t*)mmap(nullptr, guest_va_size,
                                  PROT_NONE,
                                  MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (m_host_base == MAP_FAILED) {
        LOGE("Failed to reserve %zu GB guest VA space",
             guest_va_size / (1024*1024*1024));
        m_host_base = nullptr;
        return;
    }
    LOGI("Guest VA space: %zu GB reserved at host %p",
         guest_va_size / (1024*1024*1024), m_host_base);
}

MemoryMapper::~MemoryMapper() {
    if (m_host_base) munmap(m_host_base, m_va_size);
}

void* MemoryMapper::map_region(uint64_t guest_va, size_t size, int prot) {
    if (!m_host_base || guest_va + size > m_va_size) return nullptr;
    void* host_addr = m_host_base + guest_va;
    // Commit pages with requested permissions
    if (mprotect(host_addr, size, prot) != 0) {
        LOGE("mprotect failed for VA=0x%llx", (unsigned long long)guest_va);
        return nullptr;
    }
    // Zero-fill on commit (Windows VirtualAlloc semantics)
    memset(host_addr, 0, size);
    m_committed += size;

    std::lock_guard lk(m_impl->regions_mtx);
    m_impl->regions[guest_va] = { guest_va, size, prot, -1 };
    return host_addr;
}

void MemoryMapper::unmap_region(uint64_t guest_va, size_t size) {
    if (!m_host_base) return;
    void* host_addr = m_host_base + guest_va;
    mprotect(host_addr, size, PROT_NONE); // decommit
    madvise(host_addr, size, MADV_DONTNEED); // release physical pages
    m_committed = (m_committed >= size) ? m_committed - size : 0;

    std::lock_guard lk(m_impl->regions_mtx);
    m_impl->regions.erase(guest_va);
}

bool MemoryMapper::read_guest(uint64_t guest_va, void* dst, size_t len) {
    if (!m_host_base || guest_va + len > m_va_size) return false;
    memcpy(dst, m_host_base + guest_va, len);
    return true;
}

bool MemoryMapper::write_guest(uint64_t guest_va, const void* src, size_t len) {
    if (!m_host_base || guest_va + len > m_va_size) return false;
    memcpy(m_host_base + guest_va, src, len);
    return true;
}

bool MemoryMapper::map_file(const std::string& path, uint64_t guest_va) {
    int fd = open(path.c_str(), O_RDONLY);
    if (fd < 0) { LOGE("Cannot open: %s", path.c_str()); return false; }

    struct stat st;
    fstat(fd, &st);
    size_t size = (size_t)st.st_size;

    void* host_addr = mmap(m_host_base + guest_va, size,
                            PROT_READ, MAP_PRIVATE | MAP_FIXED, fd, 0);
    close(fd);
    if (host_addr == MAP_FAILED) { LOGE("File mmap failed: %s", path.c_str()); return false; }

    m_committed += size;
    LOGI("Mapped file '%s' (%zu MB) → guest VA 0x%llx",
         path.c_str(), size / (1024*1024), (unsigned long long)guest_va);
    return true;
}

void MemoryMapper::process_pending_io() {
    std::lock_guard lk(m_impl->io_mtx);
    while (!m_impl->io_queue.empty()) {
        auto& op = m_impl->io_queue.front();
        // Prefault the page so the DBT thread doesn't stall
        if (m_host_base && op.va < m_va_size)
            madvise(m_host_base + op.va, op.len, MADV_WILLNEED);
        m_impl->io_queue.pop();
    }
}

size_t MemoryMapper::committed_bytes() const { return m_committed; }
