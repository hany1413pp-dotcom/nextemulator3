#pragma once
#include <string>
#include <memory>
#include <vector>
#include <functional>

/**
 * VirtualLAN — emulates a Windows LAN adapter over Android Wi-Fi Direct.
 *
 * Allows multiple NextEmulator instances on the same Wi-Fi network to
 * discover each other and exchange raw Ethernet frames, making PC LAN
 * multiplayer work transparently within games.
 */
class VirtualLAN {
public:
    VirtualLAN();
    ~VirtualLAN();

    bool start(const std::string& room_name = "nextemulator");
    void stop();

    // Send an Ethernet frame to all peers (broadcast)
    void send_frame(const uint8_t* data, size_t len);

    // Register a callback invoked on the network thread for each received frame
    using FrameCallback = std::function<void(const uint8_t*, size_t)>;
    void set_frame_callback(FrameCallback cb);

    // Returns the emulated MAC address assigned to this instance
    std::string local_mac() const;

    // Returns connected peer MACs
    std::vector<std::string> peer_macs() const;

private:
    struct Impl;
    std::unique_ptr<Impl> m_impl;
};
