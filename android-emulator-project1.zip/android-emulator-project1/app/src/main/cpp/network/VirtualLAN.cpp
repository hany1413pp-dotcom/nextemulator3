/**
 * VirtualLAN.cpp — UDP-based virtual Ethernet over Android Wi-Fi.
 *
 * Uses multicast UDP (224.0.0.251:7777) to discover peers on the same
 * subnet, then establishes peer-to-peer TCP sockets for frame exchange.
 * Each instance is assigned a deterministic MAC from its Android device ID.
 */
#include "VirtualLAN.h"
#include <android/log.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>
#include <thread>
#include <mutex>
#include <atomic>
#include <vector>
#include <cstring>
#include <random>

#define LOG_TAG "VirtualLAN"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static constexpr uint16_t MCAST_PORT    = 7777;
static constexpr const char* MCAST_ADDR = "224.0.0.251";

struct VirtualLAN::Impl {
    int mcast_fd  = -1;
    int server_fd = -1;

    std::atomic<bool> running{false};
    std::thread discovery_thread;
    std::thread server_thread;

    std::vector<std::string> peer_macs;
    mutable std::mutex peers_mtx;

    FrameCallback frame_cb;
    std::string   local_mac;
    std::string   room_name;

    // Generate a locally-administered MAC from random bytes
    static std::string generate_mac() {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<> dis(0, 255);
        char mac[18];
        snprintf(mac, sizeof(mac), "02:%02x:%02x:%02x:%02x:%02x",
                 dis(gen), dis(gen), dis(gen), dis(gen), dis(gen));
        return mac;
    }
};

VirtualLAN::VirtualLAN() : m_impl(std::make_unique<Impl>()) {
    m_impl->local_mac = Impl::generate_mac();
    LOGI("VirtualLAN: local MAC = %s", m_impl->local_mac.c_str());
}

VirtualLAN::~VirtualLAN() { stop(); }

bool VirtualLAN::start(const std::string& room_name) {
    m_impl->room_name = room_name;
    m_impl->running   = true;

    // UDP multicast discovery socket
    m_impl->mcast_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (m_impl->mcast_fd < 0) { LOGE("mcast socket failed"); return false; }

    int reuse = 1;
    setsockopt(m_impl->mcast_fd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));

    sockaddr_in addr{};
    addr.sin_family      = AF_INET;
    addr.sin_port        = htons(MCAST_PORT);
    addr.sin_addr.s_addr = INADDR_ANY;
    bind(m_impl->mcast_fd, (sockaddr*)&addr, sizeof(addr));

    ip_mreq mreq{};
    inet_aton(MCAST_ADDR, &mreq.imr_multiaddr);
    mreq.imr_interface.s_addr = INADDR_ANY;
    setsockopt(m_impl->mcast_fd, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreq, sizeof(mreq));

    // Discovery thread: broadcast our presence and listen for peers
    m_impl->discovery_thread = std::thread([this] {
        char buf[256];
        sockaddr_in sender{};
        socklen_t sl = sizeof(sender);

        // Broadcast our hello every 2 seconds
        std::thread beacon([this] {
            sockaddr_in dst{};
            dst.sin_family      = AF_INET;
            dst.sin_port        = htons(MCAST_PORT);
            inet_aton(MCAST_ADDR, &dst.sin_addr);
            while (m_impl->running) {
                std::string msg = "NEXTEMULAN:" + m_impl->room_name + ":" + m_impl->local_mac;
                sendto(m_impl->mcast_fd, msg.c_str(), msg.size(), 0,
                       (sockaddr*)&dst, sizeof(dst));
                std::this_thread::sleep_for(std::chrono::seconds(2));
            }
        });
        beacon.detach();

        while (m_impl->running) {
            ssize_t n = recvfrom(m_impl->mcast_fd, buf, sizeof(buf)-1, 0,
                                  (sockaddr*)&sender, &sl);
            if (n <= 0) continue;
            buf[n] = 0;
            std::string msg(buf);
            // Parse NEXTEMULAN:<room>:<mac>
            if (msg.substr(0, 11) == "NEXTEMULAN:") {
                auto pos1 = msg.find(':', 11);
                if (pos1 == std::string::npos) continue;
                auto room = msg.substr(11, pos1 - 11);
                auto mac  = msg.substr(pos1 + 1);
                if (room != m_impl->room_name) continue;
                if (mac  == m_impl->local_mac) continue;
                std::lock_guard lk(m_impl->peers_mtx);
                if (std::find(m_impl->peer_macs.begin(), m_impl->peer_macs.end(), mac)
                    == m_impl->peer_macs.end()) {
                    m_impl->peer_macs.push_back(mac);
                    LOGI("Peer discovered: %s", mac.c_str());
                }
            }
        }
    });

    LOGI("VirtualLAN started (room=%s)", room_name.c_str());
    return true;
}

void VirtualLAN::stop() {
    m_impl->running = false;
    if (m_impl->mcast_fd >= 0) { close(m_impl->mcast_fd); m_impl->mcast_fd = -1; }
    if (m_impl->discovery_thread.joinable()) m_impl->discovery_thread.join();
    LOGI("VirtualLAN stopped");
}

void VirtualLAN::send_frame(const uint8_t* data, size_t len) {
    // TODO: forward frame to all peer TCP sockets
    (void)data; (void)len;
}

void VirtualLAN::set_frame_callback(FrameCallback cb) {
    m_impl->frame_cb = std::move(cb);
}

std::string VirtualLAN::local_mac() const { return m_impl->local_mac; }

std::vector<std::string> VirtualLAN::peer_macs() const {
    std::lock_guard lk(m_impl->peers_mtx);
    return m_impl->peer_macs;
}
