#pragma once
#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <vector>

namespace dbt {

// Decoded representation of a single x86_64 basic block
struct GuestBlock {
    uint64_t guest_addr   = 0;
    uint32_t length       = 0;
    uint8_t  raw[4096]    = {};
    uint32_t raw_len      = 0;
    uint64_t branch_target= 0;
    bool     is_indirect  = false;
};

class X86_64Decoder {
public:
    X86_64Decoder();
    ~X86_64Decoder();

    bool load_executable(const char* path);

    // Returns the next block to translate, or nullopt if the queue is empty
    std::optional<GuestBlock> fetch_next_block();

    // Input injection
    void inject_key_event(uint32_t scan_code, bool pressed);
    void inject_mouse_delta(float dx, float dy);
    void inject_axis(int axis, float value);

    // CPUID spoofing so Wine thinks it's on real x86 hardware
    void spoof_cpuid(uint32_t leaf, uint32_t eax, uint32_t ebx,
                     uint32_t ecx, uint32_t edx);

private:
    struct Impl;
    std::unique_ptr<Impl> m_impl;
};

} // namespace dbt
