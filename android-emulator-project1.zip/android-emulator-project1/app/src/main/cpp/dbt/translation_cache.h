#pragma once
#include <cstdint>
#include <memory>
#include <unordered_map>
#include <shared_mutex>
#include <functional>

namespace dbt {

class Arm64Block;

/**
 * Lock-free (reader-writer locked) translation cache.
 * Maps guest (x86_64) addresses → compiled ARM64 blocks.
 * Allocated from a fixed JIT arena to keep memory footprint bounded.
 */
class TranslationCache {
public:
    explicit TranslationCache(size_t arena_bytes);
    ~TranslationCache();

    // Returns the cached block or nullptr
    Arm64Block* lookup(uint64_t guest_addr);

    // Inserts a newly compiled block
    void insert(uint64_t guest_addr, std::unique_ptr<Arm64Block> block);

    // Convenience: lookup and execute in one call
    bool get_and_execute(uint64_t guest_addr);

    // Flush the entire cache (needed after self-modifying code detected)
    void flush();

    // Current number of cached blocks
    size_t size() const;

    // Bytes used in the JIT arena
    size_t arena_used() const;

private:
    size_t m_arena_bytes;
    size_t m_arena_used = 0;

    mutable std::shared_mutex m_mtx;
    std::unordered_map<uint64_t, std::unique_ptr<Arm64Block>> m_map;

    static constexpr size_t MAX_ENTRIES = 65536; // evict oldest beyond this
};

} // namespace dbt
