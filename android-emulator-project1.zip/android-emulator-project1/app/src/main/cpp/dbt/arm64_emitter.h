#pragma once
#include "x86_64_decoder.h"
#include "translation_cache.h"
#include <cstdint>
#include <memory>
#include <vector>

namespace dbt {

// A compiled ARM64 code block ready to execute
class Arm64Block {
public:
    explicit Arm64Block(std::vector<uint32_t> insns, uint64_t guest_addr);
    void execute();
    uint64_t guest_addr() const { return m_guest_addr; }

private:
    std::vector<uint32_t> m_insns;
    uint64_t              m_guest_addr;
    void*                 m_exec_mem = nullptr; // mmap'd RWX page
};

class Arm64Emitter {
public:
    explicit Arm64Emitter(TranslationCache* cache);
    ~Arm64Emitter();

    // Translate a decoded x86_64 guest block → ARM64 block
    std::unique_ptr<Arm64Block> translate(const GuestBlock& block);

private:
    TranslationCache* m_cache;

    // Instruction handlers (x86_64 opcode → ARM64 sequence)
    std::vector<uint32_t> emit_mov_rr(uint8_t dst, uint8_t src);
    std::vector<uint32_t> emit_add_rr(uint8_t dst, uint8_t src);
    std::vector<uint32_t> emit_sub_rr(uint8_t dst, uint8_t src);
    std::vector<uint32_t> emit_jmp(uint64_t target);
    std::vector<uint32_t> emit_call(uint64_t target);
    std::vector<uint32_t> emit_ret();
    std::vector<uint32_t> emit_push(uint8_t reg);
    std::vector<uint32_t> emit_pop(uint8_t reg);

    // NEON/SIMD helpers
    std::vector<uint32_t> emit_sse_to_neon(const uint8_t* x86_bytes, size_t len);
};

} // namespace dbt
