#include "translation_cache.h"
#include "arm64_emitter.h"
#include <android/log.h>

#define LOG_TAG "DBT-Cache"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)

namespace dbt {

TranslationCache::TranslationCache(size_t arena_bytes)
    : m_arena_bytes(arena_bytes)
{
    m_map.reserve(4096);
    LOGI("TranslationCache: %zu MB JIT arena", arena_bytes / (1024*1024));
}

TranslationCache::~TranslationCache() = default;

Arm64Block* TranslationCache::lookup(uint64_t guest_addr) {
    std::shared_lock lk(m_mtx);
    auto it = m_map.find(guest_addr);
    return (it != m_map.end()) ? it->second.get() : nullptr;
}

void TranslationCache::insert(uint64_t guest_addr, std::unique_ptr<Arm64Block> block) {
    std::unique_lock lk(m_mtx);
    if (m_map.size() >= MAX_ENTRIES) {
        // Simple eviction: remove the first entry
        m_map.erase(m_map.begin());
    }
    m_map[guest_addr] = std::move(block);
}

bool TranslationCache::get_and_execute(uint64_t guest_addr) {
    Arm64Block* blk = lookup(guest_addr);
    if (!blk) return false;
    blk->execute();
    return true;
}

void TranslationCache::flush() {
    std::unique_lock lk(m_mtx);
    m_map.clear();
    m_arena_used = 0;
    LOGI("Translation cache flushed (self-modifying code detected)");
}

size_t TranslationCache::size() const {
    std::shared_lock lk(m_mtx);
    return m_map.size();
}

size_t TranslationCache::arena_used() const {
    return m_arena_used;
}

} // namespace dbt
