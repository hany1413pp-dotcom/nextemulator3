/**
 * arm64_emitter.cpp
 *
 * Translates decoded x86_64 basic blocks into native ARM64 (AArch64) code.
 * The emitted instructions are stored in an mmap'd RWX page so they can
 * be called directly as native functions.
 *
 * x86_64 register mapping:
 *   RAX → X0,  RBX → X1,  RCX → X2,  RDX → X3
 *   RSI → X4,  RDI → X5,  RSP → X6,  RBP → X7
 *   R8-R15 → X8-X15
 *   XMM0-XMM7 → V0-V7  (NEON 128-bit)
 */

#include "arm64_emitter.h"
#include <android/log.h>
#include <sys/mman.h>
#include <cstring>
#include <cassert>
#include <stdexcept>

#define LOG_TAG "DBT-Emitter"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace dbt {

// ── Arm64Block ────────────────────────────────────────────────────────────────
Arm64Block::Arm64Block(std::vector<uint32_t> insns, uint64_t guest_addr)
    : m_insns(std::move(insns)), m_guest_addr(guest_addr)
{
    size_t code_size = m_insns.size() * sizeof(uint32_t);
    // Align to page size
    size_t page_size = (size_t)sysconf(_SC_PAGESIZE);
    size_t alloc = (code_size + page_size - 1) & ~(page_size - 1);

    m_exec_mem = mmap(nullptr, alloc,
                      PROT_READ | PROT_WRITE | PROT_EXEC,
                      MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (m_exec_mem == MAP_FAILED) {
        LOGE("Failed to mmap exec page for ARM64 block");
        m_exec_mem = nullptr;
        return;
    }
    memcpy(m_exec_mem, m_insns.data(), code_size);
    // Flush instruction cache (mandatory on ARM64 after writing JIT code)
    __builtin___clear_cache((char*)m_exec_mem, (char*)m_exec_mem + code_size);
}

void Arm64Block::execute() {
    if (!m_exec_mem) return;
    using FuncPtr = void (*)();
    auto fn = reinterpret_cast<FuncPtr>(m_exec_mem);
    fn();
}

// ── Arm64Emitter ─────────────────────────────────────────────────────────────
Arm64Emitter::Arm64Emitter(TranslationCache* cache) : m_cache(cache) {}
Arm64Emitter::~Arm64Emitter() = default;

// Helper: AArch64 MOV Xd, Xn  (ORR Xd, XZR, Xn)
static uint32_t insn_mov_reg(uint8_t dst, uint8_t src) {
    // ORR Xd, XZR, Xn  — encoding: 1 01 01010 00 0 Xn 000000 11111 Xd
    return 0xAA0003E0u | ((uint32_t)src << 16) | (uint32_t)dst;
}

// Helper: AArch64 ADD Xd, Xn, Xm
static uint32_t insn_add_reg(uint8_t dst, uint8_t n, uint8_t m) {
    return 0x8B000000u | ((uint32_t)m << 16) | ((uint32_t)n << 5) | (uint32_t)dst;
}

// Helper: AArch64 SUB Xd, Xn, Xm
static uint32_t insn_sub_reg(uint8_t dst, uint8_t n, uint8_t m) {
    return 0xCB000000u | ((uint32_t)m << 16) | ((uint32_t)n << 5) | (uint32_t)dst;
}

// Helper: AArch64 RET
static uint32_t insn_ret() { return 0xD65F03C0u; }

// Helper: AArch64 NOP
static uint32_t insn_nop() { return 0xD503201Fu; }

// ── x86_64 opcode → ARM64 instruction sequences ───────────────────────────────
std::vector<uint32_t> Arm64Emitter::emit_mov_rr(uint8_t dst, uint8_t src) {
    return { insn_mov_reg(dst & 0x1F, src & 0x1F) };
}

std::vector<uint32_t> Arm64Emitter::emit_add_rr(uint8_t dst, uint8_t src) {
    // ADD Xdst, Xdst, Xsrc
    return { insn_add_reg(dst & 0x1F, dst & 0x1F, src & 0x1F) };
}

std::vector<uint32_t> Arm64Emitter::emit_sub_rr(uint8_t dst, uint8_t src) {
    return { insn_sub_reg(dst & 0x1F, dst & 0x1F, src & 0x1F) };
}

std::vector<uint32_t> Arm64Emitter::emit_ret() {
    return { insn_ret() };
}

std::vector<uint32_t> Arm64Emitter::emit_push(uint8_t reg) {
    // STR Xreg, [SP, #-16]!  — pre-indexed
    uint32_t insn = 0xF81F0FE0u | (uint32_t)(reg & 0x1F);
    return { insn };
}

std::vector<uint32_t> Arm64Emitter::emit_pop(uint8_t reg) {
    // LDR Xreg, [SP], #16  — post-indexed
    uint32_t insn = 0xF84107E0u | (uint32_t)(reg & 0x1F);
    return { insn };
}

std::vector<uint32_t> Arm64Emitter::emit_jmp(uint64_t /*target*/) {
    // In a real emitter: encode B or BL with PC-relative offset
    // Placeholder: NOP chain
    return { insn_nop(), insn_nop() };
}

std::vector<uint32_t> Arm64Emitter::emit_call(uint64_t target) {
    return emit_jmp(target); // simplified — real: BL + return stack push
}

std::vector<uint32_t> Arm64Emitter::emit_sse_to_neon(const uint8_t* /*x86_bytes*/, size_t /*len*/) {
    // SSE → NEON translation stub
    // Real implementation maps MOVAPS/MOVUPS → LDR Qn; ADDPS → FADD Vd.4S etc.
    return { insn_nop() };
}

// ── Main translate entry point ────────────────────────────────────────────────
std::unique_ptr<Arm64Block> Arm64Emitter::translate(const GuestBlock& block) {
    std::vector<uint32_t> code;
    code.reserve(block.raw_len * 4); // conservative estimate

    const uint8_t* ip  = block.raw;
    const uint8_t* end = block.raw + block.raw_len;

    while (ip < end) {
        uint8_t opcode = *ip++;

        switch (opcode) {
            case 0x89: { // MOV r/m64, r64
                uint8_t modrm = *ip++;
                uint8_t dst = modrm & 0x7;
                uint8_t src = (modrm >> 3) & 0x7;
                auto seq = emit_mov_rr(dst, src);
                code.insert(code.end(), seq.begin(), seq.end());
                break;
            }
            case 0x01: { // ADD r/m64, r64
                uint8_t modrm = *ip++;
                uint8_t dst = modrm & 0x7;
                uint8_t src = (modrm >> 3) & 0x7;
                auto seq = emit_add_rr(dst, src);
                code.insert(code.end(), seq.begin(), seq.end());
                break;
            }
            case 0x29: { // SUB r/m64, r64
                uint8_t modrm = *ip++;
                uint8_t dst = modrm & 0x7;
                uint8_t src = (modrm >> 3) & 0x7;
                auto seq = emit_sub_rr(dst, src);
                code.insert(code.end(), seq.begin(), seq.end());
                break;
            }
            case 0x50: case 0x51: case 0x52: case 0x53:
            case 0x54: case 0x55: case 0x56: case 0x57: {
                // PUSH rAX..rDI
                auto seq = emit_push(opcode - 0x50);
                code.insert(code.end(), seq.begin(), seq.end());
                break;
            }
            case 0x58: case 0x59: case 0x5A: case 0x5B:
            case 0x5C: case 0x5D: case 0x5E: case 0x5F: {
                // POP rAX..rDI
                auto seq = emit_pop(opcode - 0x58);
                code.insert(code.end(), seq.begin(), seq.end());
                break;
            }
            case 0xC3: { // RET
                auto seq = emit_ret();
                code.insert(code.end(), seq.begin(), seq.end());
                goto done;
            }
            case 0x0F: { // Two-byte opcodes (SSE etc.)
                uint8_t opcode2 = *ip++;
                auto seq = emit_sse_to_neon(ip - 2, 2);
                code.insert(code.end(), seq.begin(), seq.end());
                break;
            }
            default:
                // Unhandled — emit NOP so block doesn't crash
                code.push_back(insn_nop());
                break;
        }
    }
done:
    if (code.empty()) code.push_back(insn_ret());

    LOGD("Translated block at 0x%llx: %zu x86 bytes → %zu ARM64 insns",
         (unsigned long long)block.guest_addr, (size_t)block.raw_len, code.size());

    return std::make_unique<Arm64Block>(std::move(code), block.guest_addr);
}

} // namespace dbt
