/**
 * x86_64_decoder.cpp
 *
 * Lightweight x86_64 instruction fetcher and basic-block splitter.
 * Designed to feed blocks to Arm64Emitter for JIT compilation.
 * Integrates Box64-style CPUID spoofing so Wine reports correct CPU.
 */

#include "x86_64_decoder.h"
#include <android/log.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <elf.h>
#include <queue>
#include <mutex>
#include <cstring>
#include <cassert>

#define LOG_TAG "DBT-Decoder"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace dbt {

// ── Internal state ────────────────────────────────────────────────────────────
struct X86_64Decoder::Impl {
    uint8_t*  guest_mem     = nullptr;  // mmap'd guest address space
    size_t    guest_mem_size= 0;
    uint64_t  rip           = 0;        // current instruction pointer

    std::queue<GuestBlock> pending;
    std::mutex             pending_mtx;

    // Input queues (thread-safe)
    struct KeyEvent   { uint32_t scan; bool down; };
    struct MouseDelta { float dx, dy; };
    struct AxisEvent  { int axis; float value; };

    std::queue<KeyEvent>   key_queue;
    std::queue<MouseDelta> mouse_queue;
    std::queue<AxisEvent>  axis_queue;
    std::mutex input_mtx;

    // CPUID override table
    struct CpuidEntry { uint32_t leaf, eax, ebx, ecx, edx; };
    std::vector<CpuidEntry> cpuid_table;
};

// ── Constructor / destructor ──────────────────────────────────────────────────
X86_64Decoder::X86_64Decoder() : m_impl(std::make_unique<Impl>()) {
    // Default CPUID spoofing: report Intel Core i7-8750H to Wine
    spoof_cpuid(0x00000000, 0x16, 0x756e6547, 0x6c65746e, 0x49656e69); // GenuineIntel
    spoof_cpuid(0x00000001, 0x000906EA, 0x00100800, 0x7FFAFBBF, 0xBFEBFBFF);
    spoof_cpuid(0x00000007, 0x00000000, 0x029C67AF, 0x00000000, 0x9C002E00);
    LOGI("X86_64Decoder created with CPUID spoof (Intel Core i7-8750H)");
}

X86_64Decoder::~X86_64Decoder() {
    if (m_impl->guest_mem) {
        munmap(m_impl->guest_mem, m_impl->guest_mem_size);
    }
}

// ── ELF loader ────────────────────────────────────────────────────────────────
static bool load_elf64(const char* path, X86_64Decoder::Impl* impl) {
    int fd = open(path, O_RDONLY);
    if (fd < 0) { LOGE("open failed: %s", path); return false; }

    Elf64_Ehdr ehdr;
    if (read(fd, &ehdr, sizeof(ehdr)) != sizeof(ehdr) ||
        memcmp(ehdr.e_ident, ELFMAG, SELFMAG)) {
        LOGE("Not a valid ELF64 file: %s", path);
        close(fd);
        return false;
    }

    lseek(fd, ehdr.e_phoff, SEEK_SET);
    std::vector<Elf64_Phdr> phdrs(ehdr.e_phnum);
    read(fd, phdrs.data(), ehdr.e_phnum * sizeof(Elf64_Phdr));

    // Determine total load range
    uint64_t lo = UINT64_MAX, hi = 0;
    for (auto& ph : phdrs) {
        if (ph.p_type != PT_LOAD) continue;
        lo = std::min(lo, ph.p_vaddr);
        hi = std::max(hi, ph.p_vaddr + ph.p_memsz);
    }

    // 3 GB guest address space (mmap at fixed address)
    constexpr uint64_t GUEST_BASE = 0x100000000ULL; // above 4 GB for safety on ARM64
    size_t total = (size_t)(hi - lo + 0x100000);
    impl->guest_mem = (uint8_t*)mmap(nullptr, total,
        PROT_READ | PROT_WRITE | PROT_EXEC,
        MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (impl->guest_mem == MAP_FAILED) {
        LOGE("mmap failed for guest address space");
        close(fd);
        return false;
    }
    impl->guest_mem_size = total;

    // Load PT_LOAD segments
    for (auto& ph : phdrs) {
        if (ph.p_type != PT_LOAD || ph.p_filesz == 0) continue;
        lseek(fd, ph.p_offset, SEEK_SET);
        read(fd, impl->guest_mem + (ph.p_vaddr - lo), ph.p_filesz);
    }

    impl->rip = ehdr.e_entry - lo;
    close(fd);
    LOGI("ELF loaded: entry RIP=0x%llx", (unsigned long long)impl->rip);
    return true;
}

bool X86_64Decoder::load_executable(const char* path) {
    // Try ELF first, then fall back to PE (Wine loader will handle PE)
    std::string p(path);
    if (p.size() > 4 &&
        (p.substr(p.size()-4) == ".exe" || p.substr(p.size()-4) == ".msi")) {
        LOGI("PE executable detected — delegating to Wine loader: %s", path);
        // Wine handles PE loading; we just note the entry point via WineLoader
        // In a real build, this calls into the Wine JNI bridge
        return true;
    }
    return load_elf64(path, m_impl.get());
}

// ── Block fetch ───────────────────────────────────────────────────────────────
std::optional<GuestBlock> X86_64Decoder::fetch_next_block() {
    std::lock_guard<std::mutex> lk(m_impl->pending_mtx);
    if (!m_impl->pending.empty()) {
        auto blk = m_impl->pending.front();
        m_impl->pending.pop();
        return blk;
    }
    // In a real implementation: decode from RIP, find block end, push new block
    // For now, return nullopt when queue is empty (idle loop)
    return std::nullopt;
}

// ── Input ─────────────────────────────────────────────────────────────────────
void X86_64Decoder::inject_key_event(uint32_t scan_code, bool pressed) {
    std::lock_guard<std::mutex> lk(m_impl->input_mtx);
    m_impl->key_queue.push({scan_code, pressed});
}

void X86_64Decoder::inject_mouse_delta(float dx, float dy) {
    std::lock_guard<std::mutex> lk(m_impl->input_mtx);
    m_impl->mouse_queue.push({dx, dy});
}

void X86_64Decoder::inject_axis(int axis, float value) {
    std::lock_guard<std::mutex> lk(m_impl->input_mtx);
    m_impl->axis_queue.push({axis, value});
}

// ── CPUID spoofing ────────────────────────────────────────────────────────────
void X86_64Decoder::spoof_cpuid(uint32_t leaf,
                                 uint32_t eax, uint32_t ebx,
                                 uint32_t ecx, uint32_t edx) {
    m_impl->cpuid_table.push_back({leaf, eax, ebx, ecx, edx});
}

} // namespace dbt
