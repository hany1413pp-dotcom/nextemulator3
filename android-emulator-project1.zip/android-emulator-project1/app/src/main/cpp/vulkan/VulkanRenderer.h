#pragma once
#include <vulkan/vulkan.h>
#include <android/native_window.h>
#include <memory>
#include <vector>
#include <string>

class ShaderCache;

/**
 * VulkanRenderer
 *
 * Manages the Vulkan instance, device, swapchain, and render pipeline
 * for the Mali-G57 GPU.  Guest framebuffers (produced by WineD3D/DXVK)
 * are blitted or composited onto the swapchain image each frame.
 *
 * Key Mali-G57 optimisations:
 *  - Prefer TILED_RENDERING_BIT (AFBC) for render passes
 *  - Avoid sub-pass dependencies that flush tile memory early
 *  - Use VK_IMAGE_TILING_OPTIMAL everywhere; avoid LINEAR tiling
 *  - Pre-bake pipelines at startup from the ShaderCache
 */
class VulkanRenderer {
public:
    VulkanRenderer(ANativeWindow* window, ShaderCache* shaderCache);
    ~VulkanRenderer();

    bool init();
    void shutdown();

    void begin_frame();
    void render_guest_framebuffer(float scale);
    void end_frame();

    uint32_t width()  const { return m_width;  }
    uint32_t height() const { return m_height; }

private:
    ANativeWindow* m_window;
    ShaderCache*   m_shaderCache;
    uint32_t       m_width  = 0;
    uint32_t       m_height = 0;

    VkInstance               m_instance       = VK_NULL_HANDLE;
    VkPhysicalDevice         m_physDev        = VK_NULL_HANDLE;
    VkDevice                 m_device         = VK_NULL_HANDLE;
    VkQueue                  m_graphicsQueue  = VK_NULL_HANDLE;
    VkQueue                  m_presentQueue   = VK_NULL_HANDLE;
    VkSurfaceKHR             m_surface        = VK_NULL_HANDLE;
    VkSwapchainKHR           m_swapchain      = VK_NULL_HANDLE;
    VkRenderPass             m_renderPass     = VK_NULL_HANDLE;
    VkPipeline               m_blitPipeline   = VK_NULL_HANDLE;
    VkPipelineLayout         m_pipelineLayout = VK_NULL_HANDLE;
    VkCommandPool            m_cmdPool        = VK_NULL_HANDLE;
    VkDescriptorPool         m_descPool       = VK_NULL_HANDLE;
    VkSampler                m_sampler        = VK_NULL_HANDLE;

    std::vector<VkImage>       m_swapImages;
    std::vector<VkImageView>   m_swapViews;
    std::vector<VkFramebuffer> m_framebuffers;
    std::vector<VkCommandBuffer> m_cmdBuffers;
    std::vector<VkSemaphore>   m_imageAvailable;
    std::vector<VkSemaphore>   m_renderFinished;
    std::vector<VkFence>       m_inFlight;

    // Guest framebuffer texture (updated each emulated frame)
    VkImage        m_guestImage     = VK_NULL_HANDLE;
    VkImageView    m_guestView      = VK_NULL_HANDLE;
    VkDeviceMemory m_guestMemory    = VK_NULL_HANDLE;
    VkDescriptorSet m_guestDescSet  = VK_NULL_HANDLE;

    uint32_t m_currentFrame    = 0;
    uint32_t m_graphicsFamily  = 0;
    uint32_t m_presentFamily   = 0;

    bool createInstance();
    bool selectPhysicalDevice();
    bool createLogicalDevice();
    bool createSurface();
    bool createSwapchain();
    bool createRenderPass();
    bool createFramebuffers();
    bool createCommandPool();
    bool createSyncObjects();
    bool createBlitPipeline();
    bool createGuestTexture(uint32_t w, uint32_t h);
    void destroySwapchain();
    uint32_t findMemoryType(uint32_t filter, VkMemoryPropertyFlags props);
};
