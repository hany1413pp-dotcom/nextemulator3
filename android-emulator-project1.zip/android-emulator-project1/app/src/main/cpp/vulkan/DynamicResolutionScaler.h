#pragma once

/**
 * DynamicResolutionScaler
 *
 * Monitors actual FPS and GPU thermal status, then adjusts the internal
 * rendering resolution scale (0.5x – 1.0x) to maintain a stable target
 * frame rate on Unisoc UMS9230H without triggering thermal throttle.
 */
class DynamicResolutionScaler {
public:
    explicit DynamicResolutionScaler(float target_fps);

    // Called once per second with the measured FPS
    void tick(float measured_fps);

    // Returns the current resolution scale factor [0.5, 1.0]
    float current_scale() const;

    // Force a specific scale (e.g. from user settings)
    void set_scale(float scale);

private:
    float m_target_fps;
    float m_scale       = 1.0f;
    float m_min_scale   = 0.5f;
    float m_max_scale   = 1.0f;
    float m_step_down   = 0.05f; // step size when FPS is low
    float m_step_up     = 0.025f; // step size when FPS is stable

    int   m_stable_frames = 0; // consecutive frames at target before scaling up
    static constexpr int STABLE_THRESHOLD = 5;

    // Reads /sys/class/thermal/thermal_zone0/temp (millidegree Celsius)
    int read_cpu_temp_mC();
    static constexpr int THERMAL_LIMIT_mC = 85000; // 85 °C hard cap
};
