#include "DynamicResolutionScaler.h"
#include <android/log.h>
#include <fstream>
#include <algorithm>

#define LOG_TAG "DRS"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

DynamicResolutionScaler::DynamicResolutionScaler(float target_fps)
    : m_target_fps(target_fps) {}

void DynamicResolutionScaler::tick(float measured_fps) {
    int temp = read_cpu_temp_mC();
    bool thermal_throttle = (temp > THERMAL_LIMIT_mC);

    if (thermal_throttle || measured_fps < m_target_fps * 0.90f) {
        // FPS below 90% of target or too hot — scale down
        m_scale = std::max(m_min_scale, m_scale - m_step_down);
        m_stable_frames = 0;
        if (thermal_throttle)
            LOGI("Thermal throttle! temp=%d mC, scale→%.2f", temp, m_scale);
        else
            LOGI("FPS low (%.1f), scale→%.2f", measured_fps, m_scale);
    } else if (measured_fps >= m_target_fps * 0.98f) {
        // FPS at target — gradually restore resolution
        m_stable_frames++;
        if (m_stable_frames >= STABLE_THRESHOLD && m_scale < m_max_scale) {
            m_scale = std::min(m_max_scale, m_scale + m_step_up);
            m_stable_frames = 0;
            LOGI("FPS stable, scale→%.2f", m_scale);
        }
    }
}

float DynamicResolutionScaler::current_scale() const { return m_scale; }

void DynamicResolutionScaler::set_scale(float scale) {
    m_scale = std::clamp(scale, m_min_scale, m_max_scale);
}

int DynamicResolutionScaler::read_cpu_temp_mC() {
    std::ifstream f("/sys/class/thermal/thermal_zone0/temp");
    int temp = 0;
    if (f) f >> temp;
    return temp;
}
