#pragma once
#include <string>
#include <vector>
#include <unordered_map>

/**
 * ShaderCache — asynchronous SPIR-V shader pipeline cache for Mali-G57.
 *
 * At startup, pre-compiled SPIR-V blobs are loaded from disk (cache dir).
 * If a shader variant is missing it's compiled asynchronously so the main
 * thread never stalls (eliminates in-game compilation stutters).
 */
class ShaderCache {
public:
    explicit ShaderCache(const std::string& cacheDir);
    ~ShaderCache();

    // Returns compiled SPIR-V for a shader identified by its hash.
    // Returns empty vector if not yet compiled (async compiles it).
    std::vector<uint32_t> get_spirv(uint64_t shaderHash);

    // Pre-warm: compile a batch of shaders in the background
    void prefetch(const std::vector<uint64_t>& hashes);

    // Block until all in-flight compilations are complete
    void flush();

    // Number of cached shaders
    size_t size() const;

private:
    std::string m_cacheDir;
    struct Impl;
    std::unique_ptr<Impl> m_impl;

    std::string cache_path(uint64_t hash) const;
    std::vector<uint32_t> load_from_disk(uint64_t hash);
    void compile_async(uint64_t hash);
};
