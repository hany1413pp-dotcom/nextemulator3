# NextEmulator — GPU / CPU Configuration Profiles

## Auto-detected: Unisoc UMS9230H + Mali-G57

These settings are automatically applied when the GPU is identified as Mali-G57
(driver version string contains "Mali-G57" or Vulkan `deviceName` matches).

### Vulkan pipeline tweaks (applied in VulkanRenderer.cpp)

| Setting | Value | Reason |
|---|---|---|
| Present mode | MAILBOX (→ FIFO fallback) | Low-latency triple-buffer without tearing |
| Image tiling | OPTIMAL everywhere | Mali AFBC compression requires OPTIMAL |
| Render pass | Single subpass, no early flush | Prevents tile memory flush (TBDR arch) |
| Pipeline cache | Enabled, stored in cache dir | Eliminates re-compilation across sessions |
| Anisotropic filtering | 4x | GPU supports it; 8x/16x too costly |
| MSAA | Off (use DRS instead) | TBDR multi-sample is still expensive |

### DXVK environment variables (applied per-game profile)

```bash
DXVK_ASYNC=1                        # async pipeline compile (no stutter)
DXVK_STATE_CACHE_PATH=/sdcard/.nextem/shaders/<game_id>
DXVK_HUD=fps,memory                 # optional — disable for release builds
DXVK_LOG_LEVEL=none
WINE_FULLSCREEN_FSR=1               # AMD FSR via Wine patch
WINE_FULLSCREEN_FSR_STRENGTH=2      # 0=ultra quality … 5=performance
```

### Thread affinity map

| Thread | Cores | Priority |
|---|---|---|
| DBT translation | 0,1 (A75 big) | SCHED_FIFO max |
| Render dispatch | 2 (A55) | normal |
| I/O (pending_io) | 3,4 (A55) | SCHED_IDLE |
| Oboe audio | 5 (A55) | SCHED_FIFO (set by Oboe) |
| Network (VirtualLAN) | 6,7 (A55) | normal |

### Dynamic Resolution Scaling thresholds

| Condition | Action |
|---|---|
| FPS < 90% of target OR temp > 85°C | Scale down 5% |
| FPS ≥ 98% of target for 5s, temp < 80°C | Scale up 2.5% |
| Scale floor | 50% native resolution |
| Scale ceiling | 100% native resolution |

### Memory footprint targets

| Component | Budget |
|---|---|
| JIT code arena (TranslationCache) | 128 MB |
| Guest RAM (MemoryMapper) | ≤ 1.3 GB committed |
| Vulkan device-local (textures+FBs) | ≤ 256 MB |
| Oboe ring buffer | < 1 MB |
| Shader cache (disk) | no limit |
| **Total target RSS** | **< 700 MB** |

---

## Thermal Profile: Unisoc UMS9230H

Thermal zones polled via `/sys/class/thermal/thermal_zone*/temp`:

- **Zone 0** — CPU cluster (polled every 1 s by DynamicResolutionScaler)
- **Zone 1** — GPU (Mali driver-managed; not directly polled)

If CPU temp exceeds **85 °C**:
1. DRS immediately steps resolution down 5 %
2. JNI `onThermalWarning()` fires → Kotlin shows a toast
3. If temp stays > 90 °C for 10 s, emulation is automatically paused

---

## Shader Pre-warm List

On first launch of a known game title, the following shader hashes are
prefetched via `ShaderCache::prefetch()` so all pipelines are ready before
the first frame:

- `0x0000000000000001` — fullscreen blit (always required)
- `0x0000000000000002` — UI overlay composite
- `0x0000000000000003` — D3D9 fixed-function emulation
- `0x0000000000000004` — D3D11 deferred context replay
- `0x0000000000000005` — FXAA post-process

Game-specific hashes are loaded from `<cacheDir>/shader_list_<game_id>.json`
if present (populated after the first play session).
